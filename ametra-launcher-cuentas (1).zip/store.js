// ---------- Tienda de cosméticos ----------
// Las gemas se ganan jugando (y con el bono diario) y viven en este launcher: no hay dinero real ni servidor.
// Lo que compras se guarda en S.owned y se escribe en config/ametra.json ("owned") para que el mod lo sepa.
const GEM_PER_MIN = 6, WELCOME_GEMS = 500, DEAL_OFF = 0.3;

(function initEconomy() {
  if (typeof S.gems !== 'number') S.gems = WELCOME_GEMS;
  if (!Array.isArray(S.owned)) S.owned = [];
  // lo que ya llevabas puesto antes de existir la tienda sigue siendo tuyo
  COS_CATS.forEach(([c]) => { const id = S.cos[c]; if (id && id !== 'none' && !S.owned.includes(c + ':' + id)) S.owned.push(c + ':' + id); });
  save();
  try { writeConfig(['owned']); } catch { /* sin instancia todavía */ }
})();

// Con la sesión developer iniciada (pestaña Servidores → Developer) todo cuenta como tuyo.
const isDev = () => typeof P !== 'undefined' && !!P.dev;
// Con sesión de cuenta Ametra, las gemas y lo comprado/regalado viven en el servidor (ACC); sin sesión, en este PC.
const ownedNow = () => (ACC.on ? ACC.owned : S.owned);
const gemsNow = () => (ACC.on ? ACC.gems : S.gems);
function hasCos(cat, id) {
  const it = findCos(cat, id);
  return !!it && (isDev() || it.price === 0 || ownedNow().includes(cat + ':' + id));
}
const localDay = (d = new Date()) => d.toLocaleDateString('en-CA'); // AAAA-MM-DD en hora local

// ----- Oferta del día: un cosmético de pago distinto cada día, con 30 % de descuento -----
function dealItem() {
  if (ACC.on) return ACC.deal ? (COS_DATA.find((it) => it.cat === ACC.deal.cat && it.id === ACC.deal.id) || null) : null;
  const pool = COS_DATA.filter((it) => it.price > 0 && !hasCos(it.cat, it.id));
  if (!pool.length) return null;
  let h = 0; for (const ch of localDay()) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return pool[h % pool.length];
}
function priceOf(it) {
  if (ACC.on) return ACC.deal && ACC.deal.cat === it.cat && ACC.deal.id === it.id ? ACC.deal.price : it.price;
  const d = dealItem();
  return d && d.cat === it.cat && d.id === it.id ? Math.round(it.price * (1 - DEAL_OFF)) : it.price;
}

// ----- Ganar gemas -----
function awardPlaytime(ms) {
  const mins = Math.floor(ms / 60000);
  if (mins < 1) return;
  if (ACC.on) { // las gemas las da el servidor (solo por tiempo real y con tope diario)
    const before = ACC.gems;
    ametra.acctCall('earn', { ms }).then((v) => { accApply(v); S.lastEarn = Math.max(0, v.gems - before); save(); }).catch(() => { /* sin conexión: ese tiempo no cuenta */ });
    return;
  }
  const g = mins * GEM_PER_MIN;
  S.gems += g; S.lastEarn = g; save();
  if ($('page-store').classList.contains('active')) renderStore();
}
async function claimDaily() {
  if (ACC.on) {
    if (ACC.daily.claimed) return;
    try {
      const v = await ametra.acctCall('daily'); accApply(v);
      ST.msg = `+${v.got} gemas del bono diario (racha de ${v.daily.streak} día${v.daily.streak > 1 ? 's' : ''}). Vuelve mañana para ganar más.`;
    } catch (e) { ST.msg = cleanErr(e); }
    renderStore(); return;
  }
  const d = S.daily || { day: '', streak: 0 };
  if (d.day === localDay()) return;
  const y = new Date(); y.setDate(y.getDate() - 1);
  const streak = d.day === localDay(y) ? Math.min(d.streak + 1, 7) : 1;
  const g = 100 + (streak - 1) * 20;
  S.daily = { day: localDay(), streak }; S.gems += g; save();
  ST.msg = `+${g} gemas del bono diario (racha de ${streak} día${streak > 1 ? 's' : ''}). Vuelve mañana para ganar más.`;
  renderStore();
}

// ----- Estado y pantalla -----
const ST = { cat: 'all', sel: null, msg: '' };
const stViewer = makeViewer($('stStage'), $('stModel'), true);
stViewer.cosSrc = () => ({ ...S.cos, ...(ST.sel ? { [ST.sel.cat]: ST.sel.id } : {}) });
const ST_TABS = [['all', 'Todo'], ['mine', 'Mis cosméticos'], ...COS_CATS];

function openStoreItem(cat, id) {
  ST.cat = cat; ST.sel = findCos(cat, id) || null; ST.msg = '';
  go('store');
}
function gemEl(n) {
  const w = document.createElement('span'); w.className = 'price';
  const g = document.createElement('i'); g.className = 'gem';
  w.append(g, document.createTextNode(String(n)));
  return w;
}
async function buyItem(it) {
  const price = priceOf(it);
  if (gemsNow() < price) { ST.msg = `Te faltan ${price - gemsNow()} gemas. Juega o reclama el bono diario para ganar más.`; renderStore(); return; }
  if (!confirm(`¿Comprar "${it.name}" por ${price} gemas?`)) return;
  if (ACC.on) {
    try { accApply(await ametra.acctCall('buy', { cat: it.cat, id: it.id })); }
    catch (e) { ST.msg = cleanErr(e); renderStore(); return; }
  } else {
    S.gems -= price; S.owned.push(it.cat + ':' + it.id);
  }
  S.cos[it.cat] = it.id; // se equipa al comprarlo
  save(); writeConfig(['cape', 'cosmetics', 'owned']);
  ST.msg = `¡Es tuyo! "${it.name}" ya está equipado.`;
  renderStore();
}
function toggleEquip(it) {
  S.cos[it.cat] = S.cos[it.cat] === it.id ? 'none' : it.id;
  save(); writeConfig(['cape', 'cosmetics']); ST.msg = ''; renderStore();
}

function renderStore() {
  $('gemCount').textContent = gemsNow().toLocaleString('es');
  const claimed = ACC.on ? ACC.daily.claimed : (S.daily && S.daily.day) === localDay();

  // aviso si no hay cuenta
  const sa = $('stAcct'); sa.textContent = ''; sa.hidden = ACC.on;
  if (!ACC.on) {
    const t = document.createElement('span'); t.textContent = 'Sin cuenta: tus gemas y compras solo viven en este PC. Con una cuenta Ametra las guardas en el servidor y puedes regalar cosméticos a tus amigos.';
    const b = document.createElement('button'); b.className = 'btn'; b.textContent = 'Iniciar sesión / Crear cuenta'; b.onclick = () => go('accounts');
    sa.append(t, b);
  }
  // regalos y premios recibidos que aún no has visto
  const gb = $('giftBox'); gb.textContent = '';
  const unseen = ACC.on ? accUnseen() : [];
  gb.hidden = !unseen.length;
  if (unseen.length) {
    unseen.slice(0, 5).forEach((n) => { const p = document.createElement('p'); p.textContent = '🎁 ' + accNoteText(n); gb.appendChild(p); });
    const ok = document.createElement('button'); ok.className = 'btn'; ok.textContent = 'Entendido';
    ok.onclick = () => { ametra.acctCall('seen').then(accApply).catch(() => {}); };
    gb.appendChild(ok);
  }
  $('dailyBtn').disabled = claimed;
  $('dailyBtn').textContent = claimed ? 'Bono reclamado ✓' : 'Bono diario';

  // oferta del día
  const box = $('dealBox'); box.textContent = '';
  const d = dealItem();
  box.hidden = !d;
  if (d) {
    const cv = document.createElement('canvas'); cv.width = 72; cv.height = 72; cv.dataset.cos = d.cat + ':' + d.id; drawCosIcon(cv, d, d.cat);
    const t = document.createElement('div'); t.className = 'dealtxt';
    const tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = 'OFERTA DEL DÍA · −' + Math.round(DEAL_OFF * 100) + ' %';
    const n = document.createElement('b'); n.textContent = d.name;
    const m = document.createElement('span'); m.className = 'meta';
    const useSrv = ACC.on && ACC.dealEnds;
    const left = useSrv ? new Date(ACC.dealEnds) : new Date(); if (!useSrv) left.setHours(24, 0, 0, 0);
    const mins = Math.max(1, Math.round((left - new Date()) / 60000));
    m.textContent = `Termina en ${Math.floor(mins / 60)} h ${mins % 60} min · ${d.desc}`;
    const p = document.createElement('div'); p.className = 'dealprice';
    const old = document.createElement('s'); old.textContent = d.price;
    p.append(old, gemEl(priceOf(d)));
    t.append(tag, n, m, p);
    const go_ = document.createElement('button'); go_.className = 'btn primary'; go_.textContent = 'Probar';
    go_.onclick = () => { ST.cat = 'all'; ST.sel = d; renderStore(); };
    box.append(cv, t, go_);
  }

  // pestañas
  const tabs = $('stTabs'); tabs.textContent = '';
  ST_TABS.forEach(([id, name]) => {
    const b = document.createElement('button'); b.className = 'tab' + (ST.cat === id ? ' on' : ''); b.textContent = name;
    b.onclick = () => { ST.cat = id; renderStore(); };
    tabs.appendChild(b);
  });

  // cuadrícula
  const grid = $('stGrid'); grid.textContent = '';
  let list = COS_DATA.filter((it) => ST.cat === 'all' || (ST.cat === 'mine' ? hasCos(it.cat, it.id) : it.cat === ST.cat));
  list = list.slice().sort((a, b) => (hasCos(a.cat, a.id) - hasCos(b.cat, b.id)) || (RAR_ORDER[a.rar] - RAR_ORDER[b.rar]) || a.name.localeCompare(b.name));
  if (!list.length) { const p = document.createElement('p'); p.className = 'meta'; p.textContent = 'Aquí no hay nada todavía.'; grid.appendChild(p); }
  list.forEach((it) => {
    const have = hasCos(it.cat, it.id);
    const el = document.createElement('button');
    el.className = 'cos' + (ST.sel && ST.sel.cat === it.cat && ST.sel.id === it.id ? ' sel' : '') + (have ? ' have' : '');
    const cv = document.createElement('canvas'); cv.width = 72; cv.height = 72; cv.dataset.cos = it.cat + ':' + it.id; drawCosIcon(cv, it, it.cat);
    const n = document.createElement('span'); n.textContent = it.name;
    const r = document.createElement('span'); r.className = 'rar ' + it.rar; r.textContent = RAR_NAME[it.rar];
    el.append(cv, n, r);
    if (have) { const o = document.createElement('span'); o.className = 'owned'; o.textContent = S.cos[it.cat] === it.id ? 'EQUIPADO' : (isDev() && !ownedNow().includes(it.cat + ':' + it.id) && it.price > 0 ? 'DEV' : 'TUYO'); el.appendChild(o); }
    else {
      const pr = gemEl(priceOf(it));
      if (priceOf(it) !== it.price) { const old = document.createElement('s'); old.textContent = it.price; pr.prepend(old); }
      el.appendChild(pr);
    }
    el.onclick = () => { ST.sel = it; ST.msg = ''; renderStore(); };
    grid.appendChild(el);
  });

  // panel del cosmético elegido (probador)
  const info = $('stInfo'); info.textContent = '';
  const it = ST.sel;
  if (!it) {
    const p = document.createElement('p'); p.className = 'meta';
    p.textContent = 'Elige un cosmético para probártelo antes de comprarlo. Arrastra el personaje para girarlo.';
    info.appendChild(p);
  } else {
    const have = hasCos(it.cat, it.id);
    const h = document.createElement('b'); h.textContent = it.name;
    const rr = document.createElement('span'); rr.className = 'rar ' + it.rar; rr.textContent = RAR_NAME[it.rar];
    const ds = document.createElement('p'); ds.className = 'meta'; ds.textContent = it.desc;
    info.append(h, rr, ds);
    const b = document.createElement('button'); b.className = 'btn primary';
    if (have) { const on = S.cos[it.cat] === it.id; b.textContent = on ? 'Quitar' : 'Equipar'; if (on) b.classList.remove('primary'); b.onclick = () => toggleEquip(it); }
    else { b.textContent = 'Comprar · ' + priceOf(it) + ' gemas'; b.onclick = () => buyItem(it); }
    info.appendChild(b);
    if (it.price > 0) {
      const g = document.createElement('button'); g.className = 'btn'; g.textContent = '🎁 Regalar · ' + priceOf(it) + ' gemas';
      g.onclick = () => openGift(it); info.appendChild(g);
    }
  }
  const msg = ST.msg || (S.lastEarn ? `Tu última partida te dio ${S.lastEarn} gemas (${GEM_PER_MIN} por minuto jugado).` : `Ganas ${GEM_PER_MIN} gemas por cada minuto jugando. Las gemas son solo de este launcher.`);
  $('stMsg').textContent = msg;
  stViewer.rebuild();
}
$('dailyBtn').onclick = claimDaily;
