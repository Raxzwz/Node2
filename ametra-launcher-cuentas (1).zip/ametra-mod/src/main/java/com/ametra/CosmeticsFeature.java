package com.ametra;

import org.joml.Matrix4f;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Dibuja los cosméticos del launcher (capa, alas, sombrero, gafas, mochila) sobre el jugador local.
 * Se lee de config/ametra.json -> "cosmetics". Se ve en tercera persona (F5) y en la vista previa del inventario.
 * Coordenadas: ver tools/gen_cosmetics.py (espacio del modelo del jugador, 1 unidad = 1 píxel).
 */
public class CosmeticsFeature extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final int FULL_BRIGHT = LightmapTextureManager.MAX_LIGHT_COORDINATE;

    // estado suavizado de la capa (solo hay un jugador local)
    private static float capeAngle = 6f;
    private static long lastNs = System.nanoTime();

    public CosmeticsFeature(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, AbstractClientPlayerEntity player,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (player != MinecraftClient.getInstance().player) return;
        if (player.isInvisible() || player.isSpectator()) return;
        if (!AmetraConfig.cosmeticsOn) return;

        boolean elytra = player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
        boolean chest = !player.getEquippedStack(EquipmentSlot.CHEST).isEmpty();
        boolean helmet = !player.getEquippedStack(EquipmentSlot.HEAD).isEmpty();
        float back = chest ? 1.0f : 0f;
        float t = player.age + tickDelta;

        CosmeticData.Item cape = AmetraConfig.cosmetic("cape");
        CosmeticData.Item wings = AmetraConfig.cosmetic("wings");
        CosmeticData.Item pack = AmetraConfig.cosmetic("pack");
        CosmeticData.Item hat = AmetraConfig.cosmetic("hat");
        CosmeticData.Item glasses = AmetraConfig.cosmetic("glasses");

        PlayerEntityModel<AbstractClientPlayerEntity> model = getContextModel();

        // ---------- torso ----------
        if (cape != null && !elytra) {
            float angle = capeAngle(player, tickDelta, limbAngle, limbDistance);
            matrices.push();
            model.body.rotate(matrices);
            matrices.translate(0f, 0f, (2f + back) / 16f);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(angle));
            VertexConsumer vc = buffer(vertexConsumers, cape);
            for (CosmeticData.B b : cape.boxes) box(matrices, vc, b, 0f, 0f, 2f, 0f, light, false);
            matrices.pop();
        }

        if (wings != null && !elytra) {
            boolean air = !player.isOnGround();
            float base = player.isSneaking() ? 8f : 24f;
            float flap = air ? MathHelper.sin(t * 0.7f) * 26f + 8f : MathHelper.sin(t * 0.12f) * 4f;
            float angle = MathHelper.clamp(base + flap, 0f, 78f);
            matrices.push();
            model.body.rotate(matrices);
            VertexConsumer vc = buffer(vertexConsumers, wings);
            for (CosmeticData.B b : wings.boxes) {
                for (int s = -1; s <= 1; s += 2) { // s = +1 ala izquierda del jugador, -1 derecha
                    matrices.push();
                    matrices.translate(s * 3.0f / 16f, 0.6f / 16f, (2.8f + back) / 16f);
                    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-s * angle));
                    box(matrices, vc, b, s, 0f, 0f, 0f, light, s > 0);
                    matrices.pop();
                }
            }
            matrices.pop();
        }

        if (pack != null) {
            matrices.push();
            model.body.rotate(matrices);
            VertexConsumer vc = buffer(vertexConsumers, pack);
            boolean air = !player.isOnGround();
            for (CosmeticData.B b : pack.boxes) {
                float sy = 1f;
                if ((b.flags & 1) != 0) { // llama del jetpack
                    sy = air ? 0.85f + 0.3f * MathHelper.sin(t * 1.9f + b.x) : 0.25f;
                }
                box(matrices, vc, b, 0f, 0f, 0f, back, light, false, sy);
            }
            matrices.pop();
        }

        // ---------- cabeza ----------
        if (hat != null || (glasses != null && !helmet)) {
            matrices.push();
            model.head.rotate(matrices);
            if (hat != null) {
                VertexConsumer vc = buffer(vertexConsumers, hat);
                float lift = helmet ? -1.0f : 0f;
                for (CosmeticData.B b : hat.boxes) box(matrices, vc, b, 0f, lift, 0f, 0f, light, false);
            }
            if (glasses != null && !helmet) {
                VertexConsumer vc = buffer(vertexConsumers, glasses);
                for (CosmeticData.B b : glasses.boxes) box(matrices, vc, b, 0f, 0f, 0f, 0f, light, false);
            }
            matrices.pop();
        }
    }

    // ---------------------------------------------------------------- animación de la capa
    private static float capeAngle(AbstractClientPlayerEntity p, float tickDelta, float limbAngle, float limbDistance) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;

        float yaw = MathHelper.lerpAngleDegrees(tickDelta, p.prevBodyYaw, p.bodyYaw);
        double rad = Math.toRadians(yaw);
        double dx = p.getX() - p.prevX, dy = p.getY() - p.prevY, dz = p.getZ() - p.prevZ;
        double fwd = -dx * Math.sin(rad) + dz * Math.cos(rad); // bloques/tick hacia donde mira el cuerpo

        float lift = (float) MathHelper.clamp(fwd * 100.0, 0.0, 150.0) * 0.5f;
        float fall = MathHelper.clamp((float) (-dy) * 40f, -6f, 32f);
        float swing = MathHelper.sin(limbAngle * 0.6662f) * 8f * limbDistance;
        float sneak = p.isSneaking() ? 18f : 0f;
        float target = MathHelper.clamp(6f + lift + fall + swing + sneak, 0f, 85f);

        capeAngle += (target - capeAngle) * (1f - (float) Math.exp(-dt * 12f));
        return capeAngle;
    }

    // ---------------------------------------------------------------- dibujo
    private static VertexConsumer buffer(VertexConsumerProvider vcp, CosmeticData.Item it) {
        Identifier id = Identifier.of("ametra", "textures/cosmetics/" + it.tex + ".png");
        return vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(id));
    }

    private static void box(MatrixStack ms, VertexConsumer vc, CosmeticData.B b, float mirror, float dy, float pivotZ, float dz, int light, boolean flipU) {
        box(ms, vc, b, mirror, dy, pivotZ, dz, light, flipU, 1f);
    }

    /**
     * Dibuja una caja. mirror != 0 refleja la posición en x (alas); pivotZ se resta de z (el pivote ya está aplicado);
     * dy/dz son desplazamientos extra; flipU invierte la textura (ala izquierda); sy escala la altura (llama).
     */
    private static void box(MatrixStack ms, VertexConsumer vc, CosmeticData.B b, float mirror, float dy, float pivotZ, float dz,
                            int light, boolean flipU, float sy) {
        float cx = mirror != 0f ? b.x * mirror : b.x;
        float h = b.h * sy;
        float cy = b.y + dy;
        if ((b.flags & 1) != 0) cy = b.y - b.h * 0.5f + h * 0.5f + dy; // la llama crece hacia abajo desde su borde superior
        float cz = b.z - pivotZ + dz;
        int lt = b.glow ? FULL_BRIGHT : light;

        ms.push();
        ms.translate(cx / 16f, cy / 16f, cz / 16f);
        if (b.ry != 0f) ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(b.ry));
        MatrixStack.Entry e = ms.peek();
        Matrix4f m = e.getPositionMatrix();

        float hx = b.w / 32f, hy = h / 32f, hz = b.d / 32f;
        float u0 = flipU ? b.u1 : b.u0, u1 = flipU ? b.u0 : b.u1;

        // frente (-z): u crece con +x
        quad(vc, e, m, lt, 0, 0, -1,
            -hx, -hy, -hz, hx, -hy, -hz, hx, hy, -hz, -hx, hy, -hz, u0, b.v0, u1, b.v1);
        // espalda (+z): u crece con -x
        quad(vc, e, m, lt, 0, 0, 1,
            hx, -hy, hz, -hx, -hy, hz, -hx, hy, hz, hx, hy, hz, u0, b.v0, u1, b.v1);
        // lados y tapas
        quad(vc, e, m, lt, -1, 0, 0,
            -hx, -hy, hz, -hx, -hy, -hz, -hx, hy, -hz, -hx, hy, hz, b.s0, b.t0, b.s1, b.t1);
        quad(vc, e, m, lt, 1, 0, 0,
            hx, -hy, -hz, hx, -hy, hz, hx, hy, hz, hx, hy, -hz, b.s0, b.t0, b.s1, b.t1);
        quad(vc, e, m, lt, 0, -1, 0,
            -hx, -hy, -hz, hx, -hy, -hz, hx, -hy, hz, -hx, -hy, hz, b.s0, b.t0, b.s1, b.t1);
        quad(vc, e, m, lt, 0, 1, 0,
            -hx, hy, hz, hx, hy, hz, hx, hy, -hz, -hx, hy, -hz, b.s0, b.t0, b.s1, b.t1);
        ms.pop();
    }

    /** Un cuadrado: esquinas en orden arriba-izq, arriba-der, abajo-der, abajo-izq. */
    private static void quad(VertexConsumer vc, MatrixStack.Entry e, Matrix4f m, int light, float nx, float ny, float nz,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float u0, float v0, float u1, float v1) {
        v(vc, e, m, light, nx, ny, nz, ax, ay, az, u0, v0);
        v(vc, e, m, light, nx, ny, nz, bx, by, bz, u1, v0);
        v(vc, e, m, light, nx, ny, nz, cx, cy, cz, u1, v1);
        v(vc, e, m, light, nx, ny, nz, dx, dy, dz, u0, v1);
    }

    private static void v(VertexConsumer vc, MatrixStack.Entry e, Matrix4f m, int light, float nx, float ny, float nz,
                          float x, float y, float z, float u, float v) {
        vc.vertex(m, x, y, z).color(255, 255, 255, 255).texture(u, v).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(e, nx, ny, nz);
    }
}
