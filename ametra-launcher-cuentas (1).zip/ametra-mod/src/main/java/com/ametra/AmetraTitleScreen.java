package com.ametra;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/**
 * Menú principal propio de Ametra. Reemplaza al de Minecraft (ver MinecraftClientMixin):
 * fondo elegible (ver Backgrounds: imágenes, GIF, frames o integrados), logo animado y botones planos con el color de acento.
 * No usa el panorama de Minecraft, así que también gasta menos GPU.
 */
public class AmetraTitleScreen extends Screen {
    private static final String[] LABELS = {"Un jugador", "Multijugador", "Opciones", "Ametra", "Salir"};
    private static final int BW = 200, BH = 22, GAP = 6;

    private final float[] hov = new float[LABELS.length];
    private final int[] bx = new int[LABELS.length], by = new int[LABELS.length], bw = new int[LABELS.length];
    private float time = 0f, appear = 0f;
    private long lastNs = System.nanoTime();
    private int topY;

    public AmetraTitleScreen() {
        super(Text.literal("Ametra"));
    }

    @Override
    protected void init() {
        int contentH = 56 + 10 + 22 + 14 + 22 + 3 * (BH + GAP) + BH;
        topY = Math.max(8, (height - contentH) / 2);
        int y = topY + 56 + 10 + 22 + 14 + 22;
        int cx = width / 2;
        for (int i = 0; i < 3; i++) {
            bx[i] = cx - BW / 2;
            by[i] = y + i * (BH + GAP);
            bw[i] = BW;
        }
        int y2 = y + 3 * (BH + GAP);
        int half = (BW - GAP) / 2;
        bx[3] = cx - BW / 2;
        by[3] = y2;
        bw[3] = half;
        bx[4] = cx - BW / 2 + half + GAP;
        by[4] = y2;
        bw[4] = BW - half - GAP;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private int hit(double mx, double my) {
        for (int i = 0; i < LABELS.length; i++) {
            if (mx >= bx[i] && mx < bx[i] + bw[i] && my >= by[i] && my < by[i] + BH) return i;
        }
        return -1;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long n = System.nanoTime();
        float dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        time += dt;
        appear = Math.min(1f, appear + dt * (AmetraConfig.animations ? 2.2f : 20f));
        float ap = Colors.ease(appear);
        int ac = AmetraConfig.accent;
        int w = width, h = height;

        // fondo: el que elijas en Ametra -> Fondos (por defecto el degradado con brillos y partículas)
        Backgrounds.drawFull(ctx, w, h, time);

        // logo + título
        int cx = w / 2;
        float slide = (1f - ap) * -14f;
        float bob = (float) Math.sin(time * 1.8f) * 1.5f;
        float ly = topY + slide + bob;
        Gfx.glow(ctx, cx, ly + 28, 34 + 3f * (float) Math.sin(time * 2.4f), ac, 0.55f * ap);
        Gfx.logo(ctx, cx - 28, ly, 56, ap);

        float ty = topY + 56 + 10 + slide;
        String title = "AMETRA CLIENT";
        float ts = 2f;
        Gfx.textScaled(ctx, title, cx - Gfx.boldWidth(title) * ts / 2f, ty, ts, ac, ap, true);
        String sub = "Minecraft 1.21.1";
        Gfx.text(ctx, sub, cx - Gfx.width(sub) / 2f, ty + 22, 0x8E8E9E, ap, true);

        // botones
        int hovered = hit(mouseX, mouseY);
        for (int i = 0; i < LABELS.length; i++) {
            hov[i] += ((i == hovered ? 1f : 0f) - hov[i]) * Math.min(1f, dt * 16f);
            float k = hov[i];
            float a = Colors.clamp01(ap * 1.4f - i * 0.08f);
            float off = (1f - a) * 10f;
            float x = bx[i], y = by[i] + off, bwf = bw[i];
            Gfx.rbox(ctx, x, y, bwf, BH, Colors.lerp(0x1B1B28, ac, 0.28f * k), 0.92f * a);
            Gfx.outline(ctx, x, y, bwf, BH, ac, (0.12f + 0.55f * k) * a);
            Gfx.rect(ctx, x + 2, y + 4, 2, BH - 8, ac, (0.35f + 0.65f * k) * a);
            String l = LABELS[i];
            Gfx.text(ctx, l, x + (bwf - Gfx.width(l)) / 2f, y + (BH - 8) / 2f, Colors.lerp(0xE6E6F0, 0xFFFFFF, k), a, true);
        }

        // pie
        String key = AmetraClient.MENU_KEY == null ? "Shift derecho" : AmetraClient.MENU_KEY.getBoundKeyLocalizedText().getString();
        Gfx.text(ctx, "En el juego: " + key + " abre el menú de Ametra", 8, h - 14, 0x8E8E9E, ap, true);
        String ver = "Ametra Client " + AmetraScreen.VERSION;
        Gfx.text(ctx, ver, w - Gfx.width(ver) - 8, h - 14, 0x8E8E9E, ap, true);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int i = hit(mouseX, mouseY);
            if (i >= 0) {
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(this));
                    case 1 -> mc.setScreen(new MultiplayerScreen(this));
                    case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                    case 3 -> mc.setScreen(new AmetraScreen(this));
                    default -> mc.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
