package com.ametra;

import java.util.ArrayList;
import java.util.List;

/** GENERADO por tools/gen_cosmetics.py — no editar a mano. Geometría y UV de los cosméticos. */
public final class CosmeticData {
    private CosmeticData() {}

    /** Caja en píxeles de modelo. uv = cara frontal/trasera, uv2 = resto de caras (en texels de una hoja de 64x64). */
    public static final class B {
        public final float x, y, z, w, h, d, ry;
        public final float u0, v0, u1, v1, s0, t0, s1, t1;
        public final boolean glow;
        public final int flags;

        B(float x, float y, float z, float w, float h, float d, float ry,
          int u0, int v0, int u1, int v1, int s0, int t0, int s1, int t1, boolean glow, int flags) {
            this.x = x; this.y = y; this.z = z; this.w = w; this.h = h; this.d = d; this.ry = ry;
            this.u0 = u0 / 64f; this.v0 = v0 / 64f; this.u1 = u1 / 64f; this.v1 = v1 / 64f;
            this.s0 = s0 / 64f; this.t0 = t0 / 64f; this.s1 = s1 / 64f; this.t1 = t1 / 64f;
            this.glow = glow; this.flags = flags;
        }
    }

    public static final class Item {
        public final String cat, id, name, rar, tex;
        public final int price;
        public final B[] boxes;

        Item(String cat, String id, String name, String rar, int price, B[] boxes) {
            this.cat = cat; this.id = id; this.name = name; this.rar = rar; this.price = price; this.boxes = boxes;
            this.tex = cat + "_" + id;
        }
    }

    public static final List<Item> ALL = new ArrayList<>();

    public static Item find(String cat, String id) {
        if (id == null) return null;
        for (Item it : ALL) if (it.cat.equals(cat) && it.id.equals(id)) return it;
        return null;
    }

    static {
        ALL.add(new Item("cape", "amatista", "Amatista", "comun", 0, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "esmeralda", "Esmeralda", "comun", 150, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "hielo", "Escarcha", "raro", 450, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "rubi", "Rubí", "raro", 450, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "oro", "Oro", "raro", 450, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "noche", "Noche", "epico", 1000, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "ametra", "Ametra", "epico", 1000, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, false, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "aurora", "Aurora", "legendario", 2200, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, true, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("cape", "fuego", "Fénix", "legendario", 2200, new B[] {
            new B(0f, 7.5f, 2.7f, 9.6f, 15f, 0.7f, 0f, 0, 0, 32, 48, 36, 0, 40, 4, true, 0),
            new B(0f, 0.9f, 2.45f, 10.2f, 1.7f, 1.3f, 0f, 34, 8, 64, 13, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("wings", "angel", "Ángel", "raro", 450, new B[] {
            new B(8f, 6.5f, 0f, 16f, 18f, 0.3f, 0f, 0, 0, 32, 40, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("wings", "dragon", "Dragón", "epico", 1000, new B[] {
            new B(8f, 6.5f, 0f, 16f, 18f, 0.3f, 0f, 0, 0, 32, 40, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("wings", "mariposa", "Mariposa", "epico", 1000, new B[] {
            new B(8f, 6.5f, 0f, 16f, 18f, 0.3f, 0f, 0, 0, 32, 40, 36, 0, 40, 4, false, 0),
        }));
        ALL.add(new Item("wings", "neon", "Neón", "legendario", 2200, new B[] {
            new B(8f, 6.5f, 0f, 16f, 18f, 0.3f, 0f, 0, 0, 32, 40, 36, 0, 40, 4, true, 0),
        }));
        ALL.add(new Item("wings", "fenix", "Alas de fénix", "legendario", 2200, new B[] {
            new B(8f, 6.5f, 0f, 16f, 18f, 0.3f, 0f, 0, 0, 32, 40, 36, 0, 40, 4, true, 0),
        }));
        ALL.add(new Item("hat", "gorra", "Gorra", "comun", 0, new B[] {
            new B(0f, -9f, 0f, 9.2f, 2.4f, 9.2f, 0f, 0, 0, 24, 8, 26, 0, 34, 8, false, 0),
            new B(0f, -8.2f, -5.5f, 8.8f, 0.5f, 3f, 0f, 0, 10, 24, 18, 0, 10, 24, 18, false, 0),
            new B(0f, -8.4f, 4.8f, 6f, 1f, 0.6f, 0f, 26, 10, 34, 14, 26, 10, 34, 14, false, 0),
        }));
        ALL.add(new Item("hat", "copa", "Sombrero de copa", "raro", 450, new B[] {
            new B(0f, -8.3f, 0f, 12f, 0.6f, 12f, 0f, 0, 0, 24, 24, 0, 0, 24, 24, false, 0),
            new B(0f, -11.6f, 0f, 7f, 6.6f, 7f, 0f, 26, 0, 50, 24, 0, 26, 12, 38, false, 0),
            new B(0f, -9.4f, 0f, 7.25f, 1.1f, 7.25f, 0f, 26, 26, 54, 32, 26, 26, 54, 32, false, 0),
        }));
        ALL.add(new Item("hat", "orejas", "Orejas de gato", "raro", 450, new B[] {
            new B(0f, -8.2f, 0f, 8.6f, 0.7f, 1.6f, 0f, 0, 18, 24, 24, 0, 18, 24, 24, false, 0),
            new B(3f, -9.5f, 0f, 2.8f, 1.6f, 1.3f, 0f, 0, 0, 16, 16, 0, 0, 16, 16, false, 0),
            new B(-3f, -9.5f, 0f, 2.8f, 1.6f, 1.3f, 0f, 0, 0, 16, 16, 0, 0, 16, 16, false, 0),
            new B(3f, -10.8f, 0f, 1.6f, 1.2f, 1.1f, 0f, 0, 0, 16, 16, 0, 0, 16, 16, false, 0),
            new B(-3f, -10.8f, 0f, 1.6f, 1.2f, 1.1f, 0f, 0, 0, 16, 16, 0, 0, 16, 16, false, 0),
            new B(3f, -9.7f, -0.7f, 1.6f, 1.6f, 0.1f, 0f, 18, 0, 26, 8, 18, 0, 26, 8, false, 0),
            new B(-3f, -9.7f, -0.7f, 1.6f, 1.6f, 0.1f, 0f, 18, 0, 26, 8, 18, 0, 26, 8, false, 0),
        }));
        ALL.add(new Item("hat", "mago", "Gorro de mago", "epico", 1000, new B[] {
            new B(0f, -8.3f, 0f, 11.4f, 0.5f, 11.4f, 0f, 0, 0, 24, 24, 0, 0, 24, 24, false, 0),
            new B(0f, -9.1f, 0f, 7.9f, 1.2f, 7.9f, 0f, 0, 26, 28, 32, 0, 26, 28, 32, false, 0),
            new B(0f, -11f, 0f, 7.4f, 3f, 7.4f, 0f, 26, 0, 50, 24, 26, 0, 50, 24, false, 0),
            new B(0.4f, -13.4f, 0f, 5.4f, 2.4f, 5.4f, 0f, 26, 0, 50, 24, 26, 0, 50, 24, false, 0),
            new B(1f, -15.5f, 0f, 3.6f, 2f, 3.6f, 0f, 26, 0, 50, 24, 26, 0, 50, 24, false, 0),
            new B(1.8f, -17.2f, 0f, 2f, 1.6f, 2f, 0f, 26, 0, 50, 24, 26, 0, 50, 24, false, 0),
            new B(2.4f, -18.5f, 0f, 1.4f, 1.2f, 1.4f, 0f, 52, 0, 60, 8, 52, 0, 60, 8, false, 0),
        }));
        ALL.add(new Item("hat", "corona", "Corona", "legendario", 2200, new B[] {
            new B(0f, -8.9f, 0f, 8.8f, 1.8f, 8.8f, 0f, 0, 0, 28, 8, 30, 0, 38, 8, false, 0),
            new B(-3.3f, -10.5f, -3.3f, 1.6f, 1.8f, 1.6f, 0f, 0, 10, 8, 18, 0, 10, 8, 18, false, 0),
            new B(-3.3f, -10.5f, 3.3f, 1.6f, 1.8f, 1.6f, 0f, 0, 10, 8, 18, 0, 10, 8, 18, false, 0),
            new B(0f, -10.5f, 3.3f, 1.6f, 1.8f, 1.6f, 0f, 0, 10, 8, 18, 0, 10, 8, 18, false, 0),
            new B(3.3f, -10.5f, -3.3f, 1.6f, 1.8f, 1.6f, 0f, 0, 10, 8, 18, 0, 10, 8, 18, false, 0),
            new B(3.3f, -10.5f, 3.3f, 1.6f, 1.8f, 1.6f, 0f, 0, 10, 8, 18, 0, 10, 8, 18, false, 0),
            new B(0f, -10.8f, -3.5f, 2f, 2.6f, 1.2f, 0f, 0, 10, 8, 18, 0, 10, 8, 18, false, 0),
            new B(0f, -9f, -4.5f, 1.6f, 1.4f, 0.2f, 0f, 10, 10, 14, 14, 10, 10, 14, 14, true, 0),
        }));
        ALL.add(new Item("hat", "halo", "Halo", "legendario", 2200, new B[] {
            new B(0f, -12f, -3.6f, 8.2f, 0.9f, 1.1f, 0f, 0, 0, 16, 4, 0, 0, 16, 4, true, 0),
            new B(0f, -12f, 3.6f, 8.2f, 0.9f, 1.1f, 0f, 0, 0, 16, 4, 0, 0, 16, 4, true, 0),
            new B(-3.6f, -12f, 0f, 1.1f, 0.9f, 6.1f, 0f, 0, 0, 16, 4, 0, 0, 16, 4, true, 0),
            new B(3.6f, -12f, 0f, 1.1f, 0.9f, 6.1f, 0f, 0, 0, 16, 4, 0, 0, 16, 4, true, 0),
        }));
        ALL.add(new Item("hat", "vikingo", "Casco vikingo", "epico", 1000, new B[] {
            new B(0f, -9.6f, 0f, 9f, 3.2f, 9f, 0f, 0, 0, 24, 10, 26, 0, 34, 8, false, 0),
            new B(0f, -8.3f, 0f, 9.3f, 0.8f, 9.3f, 0f, 10, 12, 34, 16, 10, 12, 34, 16, false, 0),
            new B(-5.2f, -9.4f, 0f, 1.8f, 1.8f, 1.8f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(-6.4f, -10.8f, 0f, 1.6f, 1.8f, 1.6f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(-7.2f, -12.4f, 0f, 1.4f, 1.8f, 1.4f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(-7.6f, -14f, 0f, 1f, 1.6f, 1f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(5.2f, -9.4f, 0f, 1.8f, 1.8f, 1.8f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(6.4f, -10.8f, 0f, 1.6f, 1.8f, 1.6f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(7.2f, -12.4f, 0f, 1.4f, 1.8f, 1.4f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
            new B(7.6f, -14f, 0f, 1f, 1.6f, 1f, 0f, 0, 12, 8, 20, 0, 12, 8, 20, false, 0),
        }));
        ALL.add(new Item("glasses", "sol", "Gafas de sol", "comun", 0, new B[] {
            new B(2.2f, -4.6f, -4.4f, 3.4f, 2.2f, 0.5f, 0f, 0, 0, 16, 10, 18, 0, 22, 4, false, 0),
            new B(-2.2f, -4.6f, -4.4f, 3.4f, 2.2f, 0.5f, 0f, 0, 0, 16, 10, 18, 0, 22, 4, false, 0),
            new B(0f, -4.9f, -4.4f, 1.2f, 0.6f, 0.5f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(-4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
        }));
        ALL.add(new Item("glasses", "neon", "Gafas neón", "raro", 450, new B[] {
            new B(2.2f, -4.6f, -4.4f, 3.4f, 2.2f, 0.5f, 0f, 0, 0, 16, 10, 18, 0, 22, 4, true, 0),
            new B(-2.2f, -4.6f, -4.4f, 3.4f, 2.2f, 0.5f, 0f, 0, 0, 16, 10, 18, 0, 22, 4, true, 0),
            new B(0f, -4.9f, -4.4f, 1.2f, 0.6f, 0.5f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(-4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
        }));
        ALL.add(new Item("glasses", "corazon", "Corazón", "epico", 1000, new B[] {
            new B(2.2f, -4.4f, -4.4f, 3.8f, 2.8f, 0.5f, 0f, 0, 0, 16, 10, 18, 0, 22, 4, false, 0),
            new B(-2.2f, -4.4f, -4.4f, 3.8f, 2.8f, 0.5f, 0f, 0, 0, 16, 10, 18, 0, 22, 4, false, 0),
            new B(0f, -4.9f, -4.4f, 1.2f, 0.6f, 0.5f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(-4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
        }));
        ALL.add(new Item("glasses", "visor", "Visor", "legendario", 2200, new B[] {
            new B(0f, -4.6f, -4.5f, 8.8f, 2.2f, 0.7f, 0f, 0, 12, 32, 18, 18, 0, 22, 4, true, 0),
            new B(4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(-4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
        }));
        ALL.add(new Item("glasses", "pixel", "Gafas pixel", "epico", 1000, new B[] {
            new B(0f, -4.6f, -4.5f, 9f, 2.2f, 0.7f, 0f, 0, 20, 32, 26, 18, 0, 22, 4, false, 0),
            new B(4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
            new B(-4.15f, -4.9f, -2.2f, 0.4f, 0.5f, 4.3f, 0f, 18, 0, 22, 4, 18, 0, 22, 4, false, 0),
        }));
        ALL.add(new Item("pack", "mochila", "Mochila", "comun", 0, new B[] {
            new B(0f, 6f, 3.7f, 6f, 8f, 3f, 0f, 0, 0, 24, 32, 26, 0, 34, 8, false, 0),
            new B(0f, 3.3f, 3.95f, 6.3f, 2.8f, 3.4f, 0f, 0, 34, 26, 44, 26, 0, 34, 8, false, 0),
            new B(0f, 8.8f, 5.45f, 4f, 3f, 0.6f, 0f, 28, 34, 44, 46, 26, 0, 34, 8, false, 0),
        }));
        ALL.add(new Item("pack", "rosa", "Mochila rosa", "raro", 450, new B[] {
            new B(0f, 6f, 3.7f, 6f, 8f, 3f, 0f, 0, 0, 24, 32, 26, 0, 34, 8, false, 0),
            new B(0f, 3.3f, 3.95f, 6.3f, 2.8f, 3.4f, 0f, 0, 34, 26, 44, 26, 0, 34, 8, false, 0),
            new B(0f, 8.8f, 5.45f, 4f, 3f, 0.6f, 0f, 28, 34, 44, 46, 26, 0, 34, 8, false, 0),
        }));
        ALL.add(new Item("pack", "jetpack", "Jetpack", "epico", 1000, new B[] {
            new B(2.4f, 6.2f, 4.4f, 3.4f, 9f, 3.4f, 0f, 0, 0, 12, 36, 14, 0, 18, 4, false, 0),
            new B(2.4f, 1.2f, 4.4f, 3.6f, 1.2f, 3.6f, 0f, 20, 0, 32, 8, 20, 0, 32, 8, false, 0),
            new B(2.4f, 11.4f, 4.4f, 2.6f, 1.4f, 2.6f, 0f, 20, 10, 32, 18, 20, 10, 32, 18, false, 0),
            new B(2.4f, 13.6f, 4.4f, 1.8f, 2.6f, 1.8f, 0f, 34, 0, 42, 12, 34, 0, 42, 12, true, 1),
            new B(-2.4f, 6.2f, 4.4f, 3.4f, 9f, 3.4f, 0f, 0, 0, 12, 36, 14, 0, 18, 4, false, 0),
            new B(-2.4f, 1.2f, 4.4f, 3.6f, 1.2f, 3.6f, 0f, 20, 0, 32, 8, 20, 0, 32, 8, false, 0),
            new B(-2.4f, 11.4f, 4.4f, 2.6f, 1.4f, 2.6f, 0f, 20, 10, 32, 18, 20, 10, 32, 18, false, 0),
            new B(-2.4f, 13.6f, 4.4f, 1.8f, 2.6f, 1.8f, 0f, 34, 0, 42, 12, 34, 0, 42, 12, true, 1),
            new B(0f, 3.4f, 4.4f, 2.6f, 1.2f, 1.2f, 0f, 34, 14, 44, 18, 34, 14, 44, 18, false, 0),
        }));
    }
}
