Código fuente del mod Ametra Client (Fabric, Minecraft 1.21.1).
Mira el README de la carpeta de arriba para compilarlo.
Fuentes: src/main/java/com/ametra  ·  Recursos: src/main/resources


FONDOS DEL MENU PRINCIPAL (v1.5.0)
- Carpeta: .minecraft/<instancia>/ametra/fondos/  (el launcher la abre con "Carpeta de fondos del menu").
- Acepta PNG/JPG/BMP, GIF animados y carpetas con frames numerados (img_001.png...). "@30" al final del nombre de la
  carpeta = 30 fps (por defecto 20).
- Video a GIF:    ffmpeg -i video.mp4 -vf "fps=20,scale=640:-1" fondo.gif
- Video a frames: mkdir fondo@24 && ffmpeg -i video.mp4 -vf "fps=24,scale=640:-1" fondo@24/img_%04d.png
- Dentro del juego: Shift derecho -> FONDOS (vista previa en vivo) y COSMETICOS (equipar y ver como queda).
