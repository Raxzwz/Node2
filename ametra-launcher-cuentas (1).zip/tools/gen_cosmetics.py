#!/usr/bin/env python3
"""
Genera las texturas de los cosméticos (PNG 64x64, píxel-art con transparencia)
y el archivo CosmeticData.java que usa el mod para dibujarlos.

Uso (desde la carpeta del launcher):   python tools/gen_cosmetics.py
Necesita:  pip install pillow

Coordenadas de las cajas = píxeles de Minecraft en el espacio del modelo del jugador:
  - Cabeza: y de -8 a 0 (x ±4, z ±4). Torso: y de 0 a 12 (x ±4, z ±2).
  - El frente del jugador es z NEGATIVO, la espalda es z POSITIVO. y positivo = abajo.
  - Capa, alas y mochilas se anclan al torso; sombreros y gafas, a la cabeza.
"""
import math
import os
import random
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TEX_DIR = os.path.join(ROOT, "ametra-mod", "src", "main", "resources", "assets", "ametra", "textures", "cosmetics")
JAVA_OUT = os.path.join(ROOT, "ametra-mod", "src", "main", "java", "com", "ametra", "CosmeticData.java")


# ---------------------------------------------------------------- utilidades de color
def hx(s):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def clamp(v):
    return max(0, min(255, int(round(v))))


def shade(c, f):
    """Sombra hacia azul/violeta y luz hacia cálido (cambio de tono, como en el pixel-art profesional)."""
    if f >= 1:
        w = min(0.32, (f - 1) * 0.38)
        tint = (255, 238, 200)
    else:
        w = (1 - f) * 0.30
        tint = (28, 20, 72)
    return tuple(clamp(c[i] * f * (1 - w) + tint[i] * w) for i in range(3))


BAYER = ((0, 8, 2, 10), (12, 4, 14, 6), (3, 11, 1, 9), (15, 7, 13, 5))


def dither(c, k, x, y, steps=9, lo=0.52, hi=1.22):
    """Cuantiza el brillo k en niveles con dither ordenado: da textura de tela sin ruido."""
    v = max(0.0, min(steps - 1.0, (k - lo) / (hi - lo) * (steps - 1)))
    base = int(math.floor(v))
    if v - base > (BAYER[y % 4][x % 4] + 0.5) / 16.0:
        base += 1
    return shade(c, lo + min(base, steps - 1) * (hi - lo) / (steps - 1))


def mix(a, b, t):
    return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))


WHITE = (255, 255, 255)


class Cv:
    """Lienzo de 64x64 con transparencia."""

    def __init__(self):
        self.im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        self.p = self.im.load()

    def set(self, x, y, c, a=255):
        if 0 <= x < 64 and 0 <= y < 64:
            self.p[x, y] = (c[0], c[1], c[2], a)

    def rect(self, x0, y0, x1, y1, c, a=255):
        for y in range(y0, y1):
            for x in range(x0, x1):
                self.set(x, y, c, a)

    def clear(self, x0, y0, x1, y1):
        for y in range(y0, y1):
            for x in range(x0, x1):
                if 0 <= x < 64 and 0 <= y < 64:
                    self.p[x, y] = (0, 0, 0, 0)

    def vgrad(self, x0, y0, x1, y1, c1, c2):
        n = max(1, y1 - y0 - 1)
        for y in range(y0, y1):
            c = mix(c1, c2, (y - y0) / n)
            for x in range(x0, x1):
                self.set(x, y, c)

    def hgrad(self, x0, y0, x1, y1, c1, c2):
        n = max(1, x1 - x0 - 1)
        for x in range(x0, x1):
            c = mix(c1, c2, (x - x0) / n)
            for y in range(y0, y1):
                self.set(x, y, c)

    def frame(self, x0, y0, x1, y1, c):
        for x in range(x0, x1):
            self.set(x, y0, c)
            self.set(x, y1 - 1, c)
        for y in range(y0, y1):
            self.set(x0, y, c)
            self.set(x1 - 1, y, c)

    def jitter(self, x0, y0, x1, y1, amt, seed):
        r = random.Random(seed)
        for y in range(y0, y1):
            for x in range(x0, x1):
                px = self.p[x, y]
                if px[3] == 0:
                    continue
                f = 1 + r.uniform(-amt, amt)
                self.p[x, y] = (clamp(px[0] * f), clamp(px[1] * f), clamp(px[2] * f), px[3])

    def line(self, x0, y0, x1, y1, c, a=255):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            self.set(x0, y0, c, a)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def save(self, name):
        os.makedirs(TEX_DIR, exist_ok=True)
        self.im.save(os.path.join(TEX_DIR, name + ".png"))


def finish(cv, rects, outline=False, bevel=True):
    """Pasada final: contorno selectivo en los bordes recortados y bisel (luz arriba-izquierda)."""
    snap = cv.im.copy().load()
    for (x0, y0, x1, y1) in rects:
        big = (x1 - x0) >= 8 and (y1 - y0) >= 8
        for y in range(y0, y1):
            for x in range(x0, x1):
                px = snap[x, y]
                if px[3] == 0:
                    continue

                def clear(nx, ny):
                    if not (x0 <= nx < x1 and y0 <= ny < y1):
                        return False
                    return snap[nx, ny][3] == 0

                if outline and (clear(x + 1, y) or clear(x - 1, y) or clear(x, y + 1) or clear(x, y - 1)):
                    cv.set(x, y, shade(px[:3], 0.5), px[3])
                    continue
                if bevel and big:
                    if y == y0 or x == x0:
                        cv.set(x, y, shade(px[:3], 1.14), px[3])
                    elif y == y1 - 1 or x == x1 - 1:
                        cv.set(x, y, shade(px[:3], 0.8), px[3])
    return cv


# ---------------------------------------------------------------- definición de cosméticos
ITEMS = []


def B(x, y, z, w, h, d, uv, uv2=None, ry=0.0, glow=False, flags=0):
    return dict(x=x, y=y, z=z, w=w, h=h, d=d, uv=uv, uv2=uv2 or uv, ry=ry, glow=glow, flags=flags)


PRICES = {"comun": 150, "raro": 450, "epico": 1000, "legendario": 2200}


def item(cat, ident, name, rar, boxes, paint, price=None, desc=""):
    ITEMS.append(dict(cat=cat, id=ident, name=name, rar=rar, boxes=boxes, paint=paint,
                      price=PRICES[rar] if price is None else price, desc=desc))


# ================================================================ CAPAS
CAPE_MAIN = (0, 0, 32, 48)
CAPE_EDGE = (36, 0, 40, 4)
CAPE_COLLAR = (34, 8, 64, 13)


def gem(cv, cx, cy, r, c, hi=WHITE):
    """Diamante con facetas (luz arriba-izquierda, sombra abajo-derecha)."""
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            d = abs(dx) + abs(dy)
            if d > r:
                continue
            if d == r:
                col = shade(c, 0.45)
            elif dx + dy < -r // 2:
                col = mix(c, hi, 0.55)
            elif dx + dy > r // 2:
                col = shade(c, 0.7)
            else:
                col = c
            cv.set(cx + dx, cy + dy, col)
    cv.set(cx - r // 3, cy - r // 3, hi)


def crystal(cv, cx, cy, c, s=1.0, ring=True):
    """Cristal de Ametra: prisma hexagonal con puntas y caras iluminadas, aro dorado."""
    gold = hx("#f0c040")
    hh = int(7 * s)
    hw = max(2, int(4 * s))
    if ring:
        for dy in range(-hh - 3, hh + 4):
            for dx in range(-hw - 4, hw + 5):
                d = math.hypot(dx / (hw + 4.0), dy / (hh + 3.5))
                if 0.9 <= d <= 1.0:
                    cv.set(cx + dx, cy + dy, shade(gold, 0.85 if dx + dy > 0 else 1.15))
    for dy in range(-hh, hh + 1):
        w = hw if abs(dy) <= hh - hw else max(0, hw - (abs(dy) - (hh - hw)))
        for dx in range(-w, w + 1):
            top_face = dy < -(hh - hw) + 1 and abs(dx) <= w
            if dx < -w // 3:
                col = mix(c, WHITE, 0.42)
            elif dx > w // 3:
                col = shade(c, 0.62)
            else:
                col = shade(c, 1.12)
            if top_face and dy < -(hh - hw):
                col = mix(col, WHITE, 0.18)
            if abs(dx) == w or abs(dy) == hh:
                col = shade(c, 0.42)
            cv.set(cx + dx, cy + dy, col)
    cv.set(cx - hw // 2, cy - hh // 2, WHITE)
    cv.set(cx - hw // 2, cy - hh // 2 + 1, mix(c, WHITE, 0.8))


def crown_icon(cv, cx, cy, c):
    pts = [(-5, 2), (-5, 1), (-5, 0), (-4, 1), (-3, 2), (-2, 1), (-1, 0), (0, -1), (1, 0), (2, 1), (3, 2), (4, 1), (5, 0), (5, 1), (5, 2)]
    for dx, dy in pts:
        cv.set(cx + dx, cy + dy, shade(c, 1.2))
    for dx in range(-5, 6):
        cv.set(cx + dx, cy + 3, shade(c, 0.95))
        cv.set(cx + dx, cy + 4, shade(c, 0.6))
    for dx in (-3, 0, 3):
        cv.set(cx + dx, cy + 3, hx("#e03060"))


def flame_icon(cv, cx, cy):
    rows = ["....#....", "...##....", "..###.#..", "..#####..", ".#######.", ".###.###.", ".##...##.", "..#####.."]
    cols = [hx("#fff3b0"), hx("#ffb02e"), hx("#ff6a1a")]
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if ch == "#":
                cv.set(cx - 4 + i, cy - 4 + j, cols[min(2, max(0, (j + abs(i - 4)) // 3))] if j > 1 else cols[2])


def paint_cape(c1, c2, style, stripe=False, emblem="gem", seed=1):
    def go(cv):
        a, b = hx(c1), hx(c2)
        rnd = random.Random(seed)
        X1, Y1 = 32, 48
        # tela con degradado vertical y pliegues con dither
        for y in range(Y1):
            t = y / (Y1 - 1)
            for x in range(X1):
                fold = math.sin(x * 0.66 + 0.8) + 0.45 * math.sin(x * 1.45 + 2.1 + math.sin(y * 0.09) * 1.2)
                cv.set(x, y, dither(a, 1.13 - 0.42 * t + 0.10 * fold, x, y))

        def lit(x, y, f):
            if 0 <= x < X1 and 0 <= y < Y1:
                cv.set(x, y, shade(cv.p[x, y][:3], f))

        if style == "lattice":
            for y in range(Y1):
                for x in range(X1):
                    if (x + y) % 8 == 0 or (x - y) % 8 == 0:
                        lit(x, y, 1.2)
                    if (x + y) % 8 == 0 and (x - y) % 8 == 0:
                        cv.set(x, y, mix(cv.p[x, y][:3], WHITE, 0.5))
                    if (x + y) % 8 == 1 and (x - y) % 8 != 0:
                        lit(x, y, 0.88)
        elif style == "damask":
            for oy, ox in ((0, 0), (8, 8)):
                for cy in range(4 + oy, 44, 16):
                    for cx in range(4 + ox, 32, 16):
                        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1), (0, 2), (0, -2), (2, 0), (-2, 0)):
                            lit(cx + dx, cy + dy, 1.28)
                        for dx, dy in ((1, 1), (-1, 1), (1, -1), (-1, -1), (2, 2), (-2, 2), (2, -2), (-2, -2)):
                            lit(cx + dx, cy + dy, 0.8)
        elif style == "scales":
            for y in range(Y1):
                for x in range(X1):
                    cx = (x + (4 if (y // 4) % 2 else 0)) % 8
                    cy = y % 4
                    if cy == 3 - (abs(cx - 4) // 2) and abs(cx - 4) <= 3:
                        lit(x, y, 1.3)
                    elif cy == 0 and cx == 4:
                        lit(x, y, 0.78)
                    elif cy in (1, 2) and abs(cx - 4) <= 1:
                        lit(x, y, 1.08)
        elif style == "metal":
            for y in range(Y1):
                for x in range(X1):
                    k = (x * 2 + y) % 26
                    if k < 3:
                        cv.set(x, y, mix(cv.p[x, y][:3], WHITE, 0.34 if k == 1 else 0.16))
                    elif k > 22:
                        lit(x, y, 0.84)
            cv.jitter(0, 0, X1, Y1, 0.04, seed)
        elif style == "stars":
            for y in range(24, 44):  # nebulosa azul abajo
                for x in range(X1):
                    if (x * 3 + y * 5 + int(math.sin(x * 0.4) * 4)) % 9 < 2 and y > 24 + (x % 5):
                        cv.set(x, y, mix(cv.p[x, y][:3], hx("#2d3f7a"), 0.55))
            for _ in range(46):
                x, y = rnd.randrange(1, X1 - 1), rnd.randrange(6, 40)
                cv.set(x, y, rnd.choice([WHITE, hx("#bfe3ff"), hx("#85c1e9")]))
            for x, y in ((6, 12), (25, 20), (10, 31), (22, 33)):
                cv.set(x, y, WHITE)
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    cv.set(x + dx, y + dy, hx("#85c1e9"))
            for dy in range(-6, 7):
                for dx in range(-6, 7):
                    if dx * dx + dy * dy <= 30 and (dx - 3) ** 2 + (dy + 1) ** 2 > 26:
                        cv.set(16 + dx, 9 + dy, hx("#e8f2ff"))
        elif style == "aurora":
            for y in range(Y1):
                for x in range(X1):
                    w = (math.sin(y * 0.27 + x * 0.14) + math.sin(y * 0.11 - x * 0.2) * 0.6 + 1.6) / 3.2
                    col = mix(a, b, w)
                    if (x + y * 2) % 19 < 2:
                        col = mix(col, WHITE, 0.35)
                    cv.set(x, y, dither(col, 1.0 + 0.06 * math.sin(x * 0.9), x, y, 9, 0.9, 1.1))
            for _ in range(36):
                cv.set(rnd.randrange(1, X1 - 1), rnd.randrange(6, 42), WHITE)
        elif style == "flame":
            ramp = [hx("#fff3b0"), hx("#ffc23a"), hx("#ff7a1a"), hx("#d8321a"), hx("#7a1208")]
            for x in range(X1):
                h = 17 + 9 * abs(math.sin(x * 0.55)) + 5 * math.sin(x * 0.23 + 1.0) + (x % 3)
                for y in range(Y1):
                    t = (41 - y) / h
                    if 0 <= t < 1.0:
                        k = min(4, int(t * 5.0 + ((x + y) % 2) * 0.35))
                        cv.set(x, y, ramp[k])
            for _ in range(26):
                cv.set(rnd.randrange(1, X1 - 1), rnd.randrange(8, 30), rnd.choice([hx("#ffc23a"), hx("#ff7a1a")]))
        elif style == "frost":
            for _ in range(60):
                x, y = rnd.randrange(1, X1 - 1), rnd.randrange(5, 41)
                cv.set(x, y, rnd.choice([WHITE, hx("#d8f1ff")]))
            for ang in range(0, 360, 60):  # copo central
                r = math.radians(ang)
                ex, ey = int(16 + 11 * math.cos(r)), int(20 + 11 * math.sin(r))
                cv.line(16, 20, ex, ey, hx("#e8f7ff"))
                mx_, my_ = int(16 + 6 * math.cos(r)), int(20 + 6 * math.sin(r))
                for da in (-50, 50):
                    rr = math.radians(ang + da)
                    cv.line(mx_, my_, int(mx_ + 4 * math.cos(rr)), int(my_ + 4 * math.sin(rr)), hx("#bfe3ff"))
            for x in range(1, X1 - 1, 5):  # carámbanos en el borde inferior
                for k in range(rnd.randrange(2, 6)):
                    cv.set(x, 40 - k, hx("#e8f7ff"))
        elif style == "facets":
            for y in range(Y1):
                for x in range(X1):
                    cx_, cy_ = x % 8, y % 8
                    if (cx_ + cy_) < 8:
                        lit(x, y, 1.12 if (x // 8 + y // 8) % 2 else 0.94)
                    else:
                        lit(x, y, 0.82 if (x // 8 + y // 8) % 2 else 1.06)
                    if cx_ == 0 or cy_ == 0:
                        lit(x, y, 1.15)
        cv.jitter(0, 0, X1, Y1, 0.03, seed + 7)

        if stripe:
            for y in range(4, 43):
                for x in range(13, 19):
                    k = x - 13
                    col = shade(b, 0.7) if k in (0, 5) else (mix(b, WHITE, 0.2) if k in (1, 2) else b)
                    cv.set(x, y, col)
        # banda superior con bordado y dobladillo inferior con puntadas
        for y in range(0, 3):
            for x in range(X1):
                cv.set(x, y, shade(b, 1.1 - 0.12 * y))
        for x in range(1, X1, 4):
            cv.set(x, 1, shade(b, 1.5))
            cv.set(x + 1, 1, shade(b, 0.7))
        for x in range(X1):
            cv.set(x, 3, shade(b, 0.5))
        for y in range(41, 48):
            for x in range(X1):
                cv.set(x, y, b if y not in (41, 47) else shade(b, 0.6))
        for x in range(X1):
            cv.set(x, 42, mix(b, WHITE, 0.32))
            cv.set(x, 43, shade(b, 1.08))
        for x in range(0, X1, 4):
            cv.set(x, 45, shade(b, 0.6))
            cv.set(x + 1, 45, shade(b, 0.6))
        # bordes laterales más oscuros (da grosor)
        for y in range(Y1):
            for x, f in ((0, 0.6), (31, 0.6), (1, 0.84), (30, 0.84)):
                cv.set(x, y, shade(cv.p[x, y][:3], f))
        # emblema
        if emblem == "crystal":
            crystal(cv, 16, 22, b if style != "facets" else hx("#a47af0"), 1.0)
        elif emblem == "crystal_s":
            crystal(cv, 16, 21, b, 0.75, ring=False)
        elif emblem == "crown":
            crown_icon(cv, 16, 19, hx("#fff0c0") if style == "metal" else b)
        elif emblem == "flame":
            flame_icon(cv, 16, 21)
        elif emblem == "gem":
            gem(cv, 16, 19, 6, b, mix(b, WHITE, 0.6))
        # borde inferior festoneado (recorta la tela)
        for x in range(X1):
            m = x % 6
            depth = 2 if m in (0, 5) else (1 if m in (1, 4) else 0)
            for y in range(47 - depth + 1, 48):
                cv.p[x, y] = (0, 0, 0, 0)
        # arista y collar
        cv.rect(36, 0, 40, 4, shade(a, 0.5))
        cv.jitter(36, 0, 40, 4, 0.1, seed)
        cv.vgrad(34, 8, 64, 13, shade(b, 1.25), shade(b, 0.8))
        for x in range(35, 63, 3):
            cv.set(x, 10, shade(b, 1.5))
        cv.frame(34, 8, 64, 13, shade(b, 0.5))
        gem(cv, 38, 10, 2, a, mix(a, WHITE, 0.6))
        gem(cv, 60, 10, 2, a, mix(a, WHITE, 0.6))
        return finish(cv, [CAPE_MAIN], outline=True, bevel=False)

    return go


CAPE_BOXES = [
    B(0, 7.5, 2.7, 9.6, 15, 0.7, CAPE_MAIN, CAPE_EDGE),
    B(0, 0.9, 2.45, 10.2, 1.7, 1.3, CAPE_COLLAR, CAPE_EDGE),
]
for cid, nm, rar, c1, c2, st, stripe, emb, desc, price in [
    ("amatista", "Amatista", "comun", "#6f48c9", "#c8a8ff", "lattice", False, "crystal_s", "Tela morada con celosía y el cristal de Ametra.", 0),
    ("esmeralda", "Esmeralda", "comun", "#1f7a4d", "#8fd6a8", "scales", False, "gem", "Escamas verdes con borde bordado.", None),
    ("hielo", "Escarcha", "raro", "#4f9ccc", "#e8f7ff", "frost", False, "none", "Copo de hielo y carámbanos que brillan.", None),
    ("rubi", "Rubí", "raro", "#9b1c31", "#f1948a", "damask", False, "gem", "Damasco rojo con motivos de flor.", None),
    ("oro", "Oro", "raro", "#b8862e", "#ffd27a", "metal", True, "crown", "Metal cepillado con corona en relieve.", None),
    ("noche", "Noche", "epico", "#14161d", "#85c1e9", "stars", True, "none", "Cielo con luna, estrellas y nebulosa.", None),
    ("ametra", "Ametra", "epico", "#2a1658", "#c8a8ff", "facets", False, "crystal", "La capa oficial: facetas de amatista y gran cristal.", None),
    ("aurora", "Aurora", "legendario", "#19e3ff", "#b061e0", "aurora", True, "crystal_s", "Ondas de aurora boreal que brillan en la oscuridad.", None),
    ("fuego", "Fénix", "legendario", "#8a1a0d", "#ffb02e", "flame", False, "flame", "Llamas vivas que suben por la tela.", None),
]:
    boxes = [dict(b) for b in CAPE_BOXES]
    if cid in ("aurora", "fuego"):
        boxes[0]["glow"] = True
    item("cape", cid, nm, rar, boxes, paint_cape(c1, c2, st, stripe, emb, seed=len(cid) * 13 + ord(cid[0])), price=price, desc=desc)

# ================================================================ ALAS
WING_MAIN = (0, 0, 32, 40)
WING_EDGE = (36, 0, 40, 4)
WW, WH = 32, 40


def wing_mask(kind):
    m = [[False] * WW for _ in range(WH)]
    tops = [0.0] * WW
    if kind in ("angel", "neon", "phoenix"):
        for x in range(WW):
            t = x / (WW - 1)
            top = 11 - 10 * math.sin(math.pi * min(1, t * 1.18) * 0.85)
            bot = top + 28 * (1 - t ** 1.5) - abs((x % 5) - 2) * 0.8
            tops[x] = top
            for y in range(WH):
                m[y][x] = top <= y <= bot
    elif kind == "dragon":
        tips = [(31, 7), (23, 27), (11, 36), (0, 39)]
        for x in range(WW):
            t = x / (WW - 1)
            top = 14 - 13 * math.sin(math.pi * min(1, t * 1.1) * 0.8)
            tops[x] = top
            bot = 39
            for i in range(len(tips) - 1):
                (xa, ya), (xb, yb) = tips[i], tips[i + 1]
                if xb <= x <= xa:
                    u = (x - xb) / max(1, (xa - xb))
                    bot = yb + (ya - yb) * u - 6 * math.sin(math.pi * u)
                    break
            for y in range(WH):
                m[y][x] = top <= y <= bot
    elif kind == "butterfly":
        for y in range(WH):
            for x in range(WW):
                up = ((x - 14) / 15.5) ** 2 + ((y - 12) / 12.0) ** 2 <= 1
                lo = ((x - 10) / 10.5) ** 2 + ((y - 30) / 9.0) ** 2 <= 1
                m[y][x] = up or lo
        for x in range(WW):
            tops[x] = next((y for y in range(WH) if m[y][x]), 0)
    return m, tops


def paint_wing(kind, c1, c2, seed=3):
    def go(cv):
        a, b = hx(c1), hx(c2)
        rnd = random.Random(seed)
        m, tops = wing_mask(kind)

        def inside(x, y):
            if x < 0:
                return True
            return 0 <= x < WW and 0 <= y < WH and m[y][x]

        edge = {}
        for y in range(WH):
            for x in range(WW):
                if not m[y][x]:
                    continue
                if not (inside(x + 1, y) and inside(x - 1, y) and inside(x, y + 1) and inside(x, y - 1)):
                    edge[(x, y)] = True

        for y in range(WH):
            for x in range(WW):
                if not m[y][x]:
                    continue
                t = x / (WW - 1)
                if kind == "phoenix":
                    col = mix(hx("#b81e10"), a, min(1.0, t * 1.5))
                    col = mix(col, b, max(0.0, (t - 0.55) * 1.8) * (0.6 + 0.4 * ((x + y) % 2)))
                    if x % 4 == 0 and y > tops[x] + 6:
                        col = shade(col, 0.8)
                    elif x % 4 == 1 and y > tops[x] + 6:
                        col = shade(col, 1.12)
                    if y < tops[x] + 8 and x < 22:
                        col = mix(col, hx("#7a1208"), 0.3)
                elif kind == "angel":
                    col = mix(shade(a, 1.0), shade(b, 0.92), t * 0.8 + (y / WH) * 0.2)
                    if x % 5 == 0 and y > tops[x] + 9:
                        col = shade(col, 0.84)
                    elif x % 5 == 1 and y > tops[x] + 9:
                        col = shade(col, 1.05)
                    if y > tops[x] + 9 and (y - int(tops[x]) - 9 + (x // 5) * 3) % 7 == 6:
                        col = shade(col, 0.8)  # festón de cada fila de plumas
                    if y < tops[x] + 9 and x < 24:  # plumas cobertoras
                        col = mix(col, b, 0.35)
                        if (x + (y // 3) * 2) % 5 == 0:
                            col = shade(col, 0.88)
                elif kind == "neon":
                    col = hx("#07131c")
                    if x % 5 == 0 and y > tops[x] + 6:
                        col = shade(a, 0.45)
                    if (y - int(tops[x])) % 7 == 3 and x % 2 == 0:
                        col = shade(a, 0.35)
                elif kind == "dragon":
                    col = mix(shade(a, 1.15), shade(a, 0.7), (y / WH) * 0.7 + t * 0.2)
                    col = shade(col, 1 + 0.05 * math.sin(x * 1.3 + y * 0.9))
                elif kind == "butterfly":
                    d = math.hypot(x - 8, y - 18) / 24.0
                    col = mix(a, b, min(1.0, d * 1.15))
                    if ((x * 7 + y * 13) % 29) == 0 and d > 0.45:
                        col = WHITE
                cv.set(x, y, col)

        # huesos y detalles
        if kind == "dragon":
            bone = b
            for (tx, ty) in [(31, 7), (23, 27), (11, 36)]:
                cv.line(0, 15, tx, ty, bone)
            for x in range(0, 31):
                top = int(round(tops[x]))
                cv.set(x, top, shade(bone, 1.4))
                cv.set(x, top + 1, bone)
            for (tx, ty) in [(31, 7), (23, 27), (11, 36)]:
                cv.set(tx, ty, shade(bone, 1.6))
        if kind == "butterfly":
            for k in range(5):
                cv.line(0, 20, 28 - k * 3, 2 + k * 7, shade(a, 0.55), 160)
            for cx, cy in ((22, 9), (14, 6), (13, 32), (6, 27)):
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        if dx * dx + dy * dy <= 4:
                            cv.set(cx + dx, cy + dy, WHITE if dx * dx + dy * dy <= 1 else b)

        # contorno
        for (x, y) in edge:
            if x == 0:
                continue
            if kind == "neon":
                cv.set(x, y, mix(a, WHITE, 0.45))
                for nx, ny in ((x - 1, y), (x, y - 1), (x + 1, y), (x, y + 1)):
                    if 0 <= nx < WW and 0 <= ny < WH and m[ny][nx] and (nx, ny) not in edge:
                        cv.set(nx, ny, a)
            elif kind == "butterfly":
                cv.set(x, y, shade(a, 0.18))
                for nx, ny in ((x - 1, y), (x, y - 1), (x + 1, y), (x, y + 1)):
                    if 0 <= nx < WW and 0 <= ny < WH and m[ny][nx] and (nx, ny) not in edge:
                        cv.set(nx, ny, shade(a, 0.4))
            elif kind == "dragon":
                cv.set(x, y, shade(b, 0.8))
            elif kind == "phoenix":
                cv.set(x, y, hx("#6a0f06"))
            else:
                cv.set(x, y, shade(b, 0.62))
        # brillo en el borde superior
        if kind in ("angel", "butterfly", "phoenix"):
            for x in range(1, WW - 1):
                y = int(round(tops[x])) + 1
                if 0 <= y < WH and m[y][x]:
                    cv.set(x, y, mix(cv.p[x, y][:3], WHITE, 0.4))
        cv.jitter(0, 0, WW, WH, 0.03, seed + 5)
        cv.rect(36, 0, 40, 4, shade(b, 0.55))
        return cv

    return go


# Ala derecha en coordenadas locales de la bisagra (el mod la refleja para la izquierda).
# x = mitad del largo (el ala se extiende hacia fuera), y centrado en el hombro.
def wing_box(glow=False):
    return [B(8.0, 6.5, 0.0, 16, 18, 0.3, WING_MAIN, WING_EDGE, glow=glow)]


item("wings", "angel", "Ángel", "raro", wing_box(), paint_wing("angel", "#f4f1ff", "#cfc7f2"), desc="Plumas blancas en filas con brillo en el borde.")
item("wings", "dragon", "Dragón", "epico", wing_box(), paint_wing("dragon", "#7a1530", "#2e0612"), desc="Membrana de cuero con huesos y garras.")
item("wings", "mariposa", "Mariposa", "epico", wing_box(), paint_wing("butterfly", "#b061e0", "#f08ad0"), desc="Alas con venas y manchas de luz.")
item("wings", "neon", "Neón", "legendario", wing_box(True), paint_wing("neon", "#19e3ff", "#0a7f93"), desc="Circuito de neón que brilla en la oscuridad.")
item("wings", "fenix", "Alas de fénix", "legendario", wing_box(True), paint_wing("phoenix", "#ff7a1a", "#ffd23c"), desc="Plumas de fuego del naranja al amarillo.")

# ================================================================ SOMBREROS (anclados a la cabeza)


def weave(cv, r, c, amt=0.06, seed=1):
    cv.rect(r[0], r[1], r[2], r[3], c)
    cv.jitter(r[0], r[1], r[2], r[3], amt, seed)


def stitch(cv, x0, x1, y, c, step=3):
    for x in range(x0, x1, step):
        cv.set(x, y, c)
        cv.set(x + 1, y, c)


# --- Gorra
CAP_CROWN, CAP_TOP, CAP_VISOR, CAP_STRAP = (0, 0, 24, 8), (26, 0, 34, 8), (0, 10, 24, 18), (26, 10, 34, 14)


def paint_gorra(cv):
    red, dark = hx("#d94141"), hx("#a82e2e")
    cv.vgrad(*CAP_CROWN, shade(red, 1.15), shade(red, 0.85))
    cv.jitter(*CAP_CROWN, 0.05, 2)
    for x in range(0, 24):
        cv.set(x, 5, WHITE)
        cv.set(x, 6, shade(WHITE, 0.82))
    gem(cv, 12, 2, 2, hx("#ffd27a"), WHITE)
    weave(cv, CAP_TOP, red, 0.06, 3)
    for k in range(0, 8):
        cv.set(k, 0, shade(red, 0.7))  # costuras (se ven en la cara de arriba)
    cv.rect(29, 3, 31, 5, shade(red, 0.6))
    cv.vgrad(*CAP_VISOR, shade(dark, 1.2), shade(dark, 0.8))
    cv.jitter(*CAP_VISOR, 0.05, 4)
    stitch(cv, 1, 23, 12, shade(dark, 1.5))
    stitch(cv, 1, 23, 16, shade(dark, 1.5))
    cv.frame(*CAP_VISOR, shade(dark, 0.55))
    weave(cv, CAP_STRAP, dark, 0.05, 5)
    return finish(cv, [CAP_CROWN, CAP_TOP, CAP_VISOR])


item("hat", "gorra", "Gorra", "comun", [
    B(0, -9.0, 0, 9.2, 2.4, 9.2, CAP_CROWN, CAP_TOP),
    B(0, -8.2, -5.5, 8.8, 0.5, 3.0, CAP_VISOR, CAP_VISOR),
    B(0, -8.4, 4.8, 6.0, 1.0, 0.6, CAP_STRAP, CAP_STRAP),
], paint_gorra, desc="Gorra roja con costuras y visera.", price=0)

# --- Sombrero de copa
TOP_BRIM, TOP_BODY, TOP_BTOP, TOP_BAND = (0, 0, 24, 24), (26, 0, 50, 24), (0, 26, 12, 38), (26, 26, 54, 32)


def paint_copa(cv):
    blk = hx("#15151d")
    cv.rect(*TOP_BRIM, blk)
    for y in range(24):
        for x in range(24):
            d = math.hypot(x - 11.5, y - 11.5)
            if 4 < d < 6:
                cv.set(x, y, shade(blk, 0.6))
    cv.jitter(*TOP_BRIM, 0.18, 5)
    cv.hgrad(*TOP_BODY, shade(blk, 1.7), shade(blk, 0.75))
    for y in range(0, 24):
        cv.set(29, y, shade(blk, 2.3))
        cv.set(30, y, shade(blk, 2.0))
    cv.jitter(*TOP_BODY, 0.05, 6)
    cv.rect(*TOP_BTOP, shade(blk, 1.1))
    cv.frame(*TOP_BTOP, shade(blk, 1.9))
    cv.rect(*TOP_BAND, hx("#8a5be0"))
    cv.vgrad(*TOP_BAND, hx("#a47af0"), hx("#6a43b8"))
    cv.rect(38, 26, 44, 32, hx("#f0c040"))
    cv.rect(40, 28, 42, 30, shade(hx("#f0c040"), 0.45))
    cv.frame(38, 26, 44, 32, hx("#9a7a18"))
    return finish(cv, [TOP_BRIM, TOP_BODY, TOP_BAND])


item("hat", "copa", "Sombrero de copa", "raro", [
    B(0, -8.3, 0, 12, 0.6, 12, TOP_BRIM, TOP_BRIM),
    B(0, -11.6, 0, 7, 6.6, 7, TOP_BODY, TOP_BTOP),
    B(0, -9.4, 0, 7.25, 1.1, 7.25, TOP_BAND, TOP_BAND),
], paint_copa, desc="Seda negra con cinta de amatista y hebilla.")

# --- Orejas de gato
CAT_FUR, CAT_PINK, CAT_BAND = (0, 0, 16, 16), (18, 0, 26, 8), (0, 18, 24, 24)


def paint_orejas(cv):
    fur = hx("#2a2a36")
    cv.rect(*CAT_FUR, fur)
    r = random.Random(11)
    for _ in range(40):
        cv.set(r.randrange(0, 16), r.randrange(0, 16), shade(fur, r.choice([1.5, 0.7])))
    cv.rect(*CAT_PINK, hx("#f08ad0"))
    for y in range(0, 8):
        for x in range(18, 26):
            if math.hypot(x - 21.5, y - 3.5) < 3:
                cv.set(x, y, hx("#ffc2ea"))
    cv.rect(*CAT_BAND, shade(fur, 0.9))
    cv.jitter(*CAT_BAND, 0.1, 12)
    return finish(cv, [CAT_FUR, CAT_BAND])


item("hat", "orejas", "Orejas de gato", "raro", [
    B(0, -8.2, 0, 8.6, 0.7, 1.6, CAT_BAND, CAT_BAND),
    B(3, -9.5, 0, 2.8, 1.6, 1.3, CAT_FUR, CAT_FUR),
    B(-3, -9.5, 0, 2.8, 1.6, 1.3, CAT_FUR, CAT_FUR),
    B(3, -10.8, 0, 1.6, 1.2, 1.1, CAT_FUR, CAT_FUR),
    B(-3, -10.8, 0, 1.6, 1.2, 1.1, CAT_FUR, CAT_FUR),
    B(3, -9.7, -0.7, 1.6, 1.6, 0.1, CAT_PINK, CAT_PINK),
    B(-3, -9.7, -0.7, 1.6, 1.6, 0.1, CAT_PINK, CAT_PINK),
], paint_orejas, desc="Pelaje oscuro con interior rosa.")

# --- Gorro de mago
WZ_BRIM, WZ_TIER, WZ_BAND, WZ_TIP = (0, 0, 24, 24), (26, 0, 50, 24), (0, 26, 28, 32), (52, 0, 60, 8)


def star(cv, cx, cy, c):
    cv.set(cx, cy, c)
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        cv.set(cx + dx, cy + dy, mix(c, (90, 56, 176), 0.4))


def paint_mago(cv):
    pur, gold = hx("#5a38b0"), hx("#ffd27a")
    cv.rect(*WZ_BRIM, hx("#3b2a7a"))
    for y in range(24):
        for x in range(24):
            d = math.hypot(x - 11.5, y - 11.5)
            if 9.5 < d < 10.8:
                cv.set(x, y, gold)
    cv.jitter(*WZ_BRIM, 0.08, 21)
    cv.vgrad(*WZ_TIER, shade(pur, 1.2), shade(pur, 0.78))
    r = random.Random(22)
    for _ in range(7):
        star(cv, r.randrange(28, 48), r.randrange(2, 22), gold if r.random() < 0.6 else WHITE)
    cv.jitter(*WZ_TIER, 0.05, 23)
    cv.rect(*WZ_BAND, hx("#2a1d5c"))
    cv.rect(11, 26, 17, 32, gold)
    cv.rect(13, 28, 15, 30, shade(gold, 0.4))
    cv.frame(11, 26, 17, 32, shade(gold, 0.6))
    cv.rect(*WZ_TIP, gold)
    cv.jitter(*WZ_TIP, 0.1, 24)
    cv.set(53, 1, WHITE)
    return finish(cv, [WZ_BRIM, WZ_TIER, WZ_BAND])


item("hat", "mago", "Gorro de mago", "epico", [
    B(0, -8.3, 0, 11.4, 0.5, 11.4, WZ_BRIM, WZ_BRIM),
    B(0, -9.1, 0, 7.9, 1.2, 7.9, WZ_BAND, WZ_BAND),
    B(0, -11.0, 0, 7.4, 3.0, 7.4, WZ_TIER, WZ_TIER),
    B(0.4, -13.4, 0, 5.4, 2.4, 5.4, WZ_TIER, WZ_TIER),
    B(1.0, -15.5, 0, 3.6, 2.0, 3.6, WZ_TIER, WZ_TIER),
    B(1.8, -17.2, 0, 2.0, 1.6, 2.0, WZ_TIER, WZ_TIER),
    B(2.4, -18.5, 0, 1.4, 1.2, 1.4, WZ_TIP, WZ_TIP),
], paint_mago, desc="Gorro con estrellas doradas y borde bordado.")

# --- Corona
CR_RING, CR_SIDE, CR_SPIKE, CR_GEM = (0, 0, 28, 8), (30, 0, 38, 8), (0, 10, 8, 18), (10, 10, 14, 14)


def paint_corona(cv):
    gold = hx("#f0c040")
    cv.vgrad(*CR_RING, shade(gold, 1.25), shade(gold, 0.78))
    for x in range(28):
        cv.set(x, 0, shade(gold, 1.5))
        cv.set(x, 7, shade(gold, 0.55))
        if x % 4 < 2:
            cv.set(x, 3, shade(gold, 0.7))
    for cx in (5, 14, 23):
        gem(cv, cx, 4, 2, hx("#e03060") if cx != 14 else hx("#19b8e0"), WHITE)
    cv.jitter(*CR_RING, 0.05, 31)
    cv.rect(*CR_SIDE, gold)
    cv.jitter(*CR_SIDE, 0.12, 32)
    cv.vgrad(*CR_SPIKE, shade(gold, 1.4), shade(gold, 0.8))
    cv.jitter(*CR_SPIKE, 0.06, 33)
    cv.frame(*CR_SPIKE, shade(gold, 0.6))
    cv.rect(*CR_GEM, hx("#e03060"))
    cv.rect(11, 11, 13, 13, hx("#ff9ab8"))
    return finish(cv, [CR_RING, CR_SPIKE])


crown_spikes = [B(x, -10.5, z, 1.6, 1.8, 1.6, CR_SPIKE, CR_SPIKE) for x in (-3.3, 0.0, 3.3) for z in (-3.3, 3.3) if not (x == 0.0 and z == -3.3)]
item("hat", "corona", "Corona", "legendario", [
    B(0, -8.9, 0, 8.8, 1.8, 8.8, CR_RING, CR_SIDE),
    *crown_spikes,
    B(0, -10.8, -3.5, 2.0, 2.6, 1.2, CR_SPIKE, CR_SPIKE),
    B(0, -9.0, -4.5, 1.6, 1.4, 0.2, CR_GEM, CR_GEM, glow=True),
], paint_corona, desc="Oro con gemas y puntas brillantes.")

# --- Halo
HL_BAR = (0, 0, 16, 4)


def paint_halo(cv):
    for x in range(16):
        t = abs(x - 7.5) / 8
        for y in range(4):
            c = mix(hx("#fff6c8"), hx("#ffd966"), t * 0.8 + (y / 3) * 0.2)
            cv.set(x, y, c)
    for x in range(1, 16, 4):
        cv.set(x, 1, WHITE)
    return cv


item("hat", "halo", "Halo", "legendario", [
    B(0, -12.0, -3.6, 8.2, 0.9, 1.1, HL_BAR, HL_BAR, glow=True),
    B(0, -12.0, 3.6, 8.2, 0.9, 1.1, HL_BAR, HL_BAR, glow=True),
    B(-3.6, -12.0, 0, 1.1, 0.9, 6.1, HL_BAR, HL_BAR, glow=True),
    B(3.6, -12.0, 0, 1.1, 0.9, 6.1, HL_BAR, HL_BAR, glow=True),
], paint_halo, desc="Aro de luz dorada flotando sobre tu cabeza.")

# --- Casco vikingo
VK_DOME, VK_TOP, VK_HORN, VK_BAND = (0, 0, 24, 10), (26, 0, 34, 8), (0, 12, 8, 20), (10, 12, 34, 16)


def paint_vikingo(cv):
    steel = hx("#8e95a8")
    cv.vgrad(*VK_DOME, shade(steel, 1.25), shade(steel, 0.75))
    for x in range(1, 24, 4):  # remaches
        cv.set(x, 6, shade(steel, 1.7))
        cv.set(x, 7, shade(steel, 0.5))
    for x in range(24):
        cv.set(x, 9, hx("#5a3a1e"))
    cv.jitter(*VK_DOME, 0.06, 61)
    cv.rect(*VK_TOP, shade(steel, 1.05))
    cv.frame(*VK_TOP, shade(steel, 0.6))
    ivory = hx("#f1e8cf")
    cv.vgrad(*VK_HORN, ivory, shade(ivory, 0.78))
    for y in (14, 17):
        for x in range(8):
            cv.set(x, y, shade(ivory, 0.62))
    cv.hgrad(*VK_BAND, hx("#6a4424"), hx("#4a2e16"))
    for x in range(11, 33, 4):
        cv.set(x, 14, hx("#e0b040"))
    return finish(cv, [VK_DOME, VK_TOP, VK_BAND])


vk = [
    B(0, -9.6, 0, 9.0, 3.2, 9.0, VK_DOME, VK_TOP),
    B(0, -8.3, 0, 9.3, 0.8, 9.3, VK_BAND, VK_BAND),
]
for sx in (-1, 1):
    vk += [
        B(sx * 5.2, -9.4, 0, 1.8, 1.8, 1.8, VK_HORN, VK_HORN),
        B(sx * 6.4, -10.8, 0, 1.6, 1.8, 1.6, VK_HORN, VK_HORN),
        B(sx * 7.2, -12.4, 0, 1.4, 1.8, 1.4, VK_HORN, VK_HORN),
        B(sx * 7.6, -14.0, 0, 1.0, 1.6, 1.0, VK_HORN, VK_HORN),
    ]
item("hat", "vikingo", "Casco vikingo", "epico", vk, paint_vikingo, desc="Casco de acero con remaches y cuernos de marfil.")

# ================================================================ GAFAS (cabeza)
GL_LENS, GL_FRAME, GL_BAR = (0, 0, 16, 10), (18, 0, 22, 4), (0, 12, 32, 18)


def paint_glasses(kind, lens, frame):
    def go(cv):
        l, f = hx(lens), hx(frame)
        if kind == "visor":
            cv.hgrad(*GL_BAR, hx("#5a38b0"), hx("#c8a8ff"))
            for x in range(0, 32, 4):
                cv.set(x, 14, mix(hx("#c8a8ff"), WHITE, 0.6))
                cv.set(x + 1, 15, mix(hx("#c8a8ff"), WHITE, 0.4))
            cv.frame(*GL_BAR, hx("#2a1d5c"))
            cv.rect(*GL_FRAME, hx("#2a1d5c"))
            return cv
        for y in range(10):
            for x in range(16):
                if kind == "heart":
                    # corazón
                    fx, fy = (x - 7.5) / 6.4, (y - 4.2) / 4.6
                    inside = (fx * fx + (fy - math.sqrt(abs(fx))) ** 2) <= 1.0
                    if not inside:
                        continue
                cv.set(x, y, mix(shade(l, 1.1), shade(l, 0.7), y / 9))
        if kind == "sun":
            for k in range(0, 9):
                cv.set(2 + k, 7 - k // 2, mix(hx("#3a3a50"), WHITE, 0.3))
        elif kind == "neon":
            for k in range(0, 8):
                cv.set(2 + k, 6 - k // 2, mix(l, WHITE, 0.7))
            cv.frame(0, 0, 16, 10, mix(l, WHITE, 0.5))
        elif kind == "heart":
            cv.set(4, 2, WHITE)
            cv.set(5, 2, WHITE)
            cv.set(4, 3, WHITE)
        cv.rect(*GL_FRAME, f)
        return cv

    return go


GL_BOXES = [
    B(2.2, -4.6, -4.4, 3.4, 2.2, 0.5, GL_LENS, GL_FRAME),
    B(-2.2, -4.6, -4.4, 3.4, 2.2, 0.5, GL_LENS, GL_FRAME),
    B(0, -4.9, -4.4, 1.2, 0.6, 0.5, GL_FRAME, GL_FRAME),
    B(4.15, -4.9, -2.2, 0.4, 0.5, 4.3, GL_FRAME, GL_FRAME),
    B(-4.15, -4.9, -2.2, 0.4, 0.5, 4.3, GL_FRAME, GL_FRAME),
]
item("glasses", "sol", "Gafas de sol", "comun", [dict(b) for b in GL_BOXES], paint_glasses("sun", "#0d0d12", "#0d0d12"), desc="Lentes oscuros con un reflejo.", price=0)
neon_boxes = [dict(b) for b in GL_BOXES]
neon_boxes[0]["glow"] = neon_boxes[1]["glow"] = True
item("glasses", "neon", "Gafas neón", "raro", neon_boxes, paint_glasses("neon", "#19e3ff", "#0a7f93"), desc="Lentes de neón que brillan.")
heart_boxes = [dict(b) for b in GL_BOXES]
heart_boxes[0].update(w=3.8, h=2.8, y=-4.4)
heart_boxes[1].update(w=3.8, h=2.8, y=-4.4)
item("glasses", "corazon", "Corazón", "epico", heart_boxes, paint_glasses("heart", "#ff4f8b", "#ffd0e0"), desc="Lentes en forma de corazón.")
item("glasses", "visor", "Visor", "legendario", [
    B(0, -4.6, -4.5, 8.8, 2.2, 0.7, GL_BAR, GL_FRAME, glow=True),
    B(4.15, -4.9, -2.2, 0.4, 0.5, 4.3, GL_FRAME, GL_FRAME),
    B(-4.15, -4.9, -2.2, 0.4, 0.5, 4.3, GL_FRAME, GL_FRAME),
], paint_glasses("visor", "#8a5be0", "#5a38b0"), desc="Visor de energía que brilla.")

# --- Gafas pixel (estilo "deal with it")
GL_PIX = (0, 20, 32, 26)


def paint_pixshades(cv):
    for y in range(6):
        for x in range(32):
            cv.set(x, y + 20, hx("#0b0b10"))
    for x in range(32):  # muescas escalonadas abajo y en el puente
        cut = 0
        if x in (0, 1, 30, 31):
            cut = 2
        elif x in (2, 3, 28, 29):
            cut = 1
        elif 13 <= x <= 18:
            cut = 3
        elif x in (12, 19):
            cut = 2
        for k in range(cut):
            cv.p[x, 25 - k] = (0, 0, 0, 0)
    for x in range(2, 12):  # brillo en los pixeles
        cv.set(x, 21, hx("#2a2a36"))
    for x in range(20, 30):
        cv.set(x, 21, hx("#2a2a36"))
    cv.set(4, 22, WHITE); cv.set(5, 22, WHITE); cv.set(22, 22, WHITE); cv.set(23, 22, WHITE)
    cv.rect(*GL_FRAME, hx("#0b0b10"))
    return cv


item("glasses", "pixel", "Gafas pixel", "epico", [
    B(0, -4.6, -4.5, 9.0, 2.2, 0.7, GL_PIX, GL_FRAME),
    B(4.15, -4.9, -2.2, 0.4, 0.5, 4.3, GL_FRAME, GL_FRAME),
    B(-4.15, -4.9, -2.2, 0.4, 0.5, 4.3, GL_FRAME, GL_FRAME),
], paint_pixshades, desc="Gafas de 8 bits: el clásico meme en tu cara.")

# ================================================================ MOCHILAS (torso)
PK_MAIN, PK_SIDE, PK_LID, PK_POCKET = (0, 0, 24, 32), (26, 0, 34, 8), (0, 34, 26, 44), (28, 34, 44, 46)


def paint_pack(c1, c2, dots=False):
    def go(cv):
        a, b = hx(c1), hx(c2)
        cv.vgrad(*PK_MAIN, shade(a, 1.12), shade(a, 0.82))
        cv.jitter(*PK_MAIN, 0.07, 41)
        for x in range(2, 22, 3):  # costura punteada
            cv.set(x, 2, shade(a, 1.5))
            cv.set(x, 29, shade(a, 1.5))
        for y in range(2, 30, 3):
            cv.set(2, y, shade(a, 1.5))
            cv.set(21, y, shade(a, 1.5))
        for y in range(0, 32):
            cv.set(11, y, shade(a, 0.7))
            cv.set(12, y, shade(a, 1.2))
        if dots:
            r = random.Random(44)
            for _ in range(14):
                cx, cy = r.randrange(3, 21), r.randrange(4, 28)
                cv.set(cx, cy, WHITE)
                cv.set(cx + 1, cy, shade(WHITE, 0.85))
        cv.frame(*PK_MAIN, shade(a, 0.5))
        cv.rect(*PK_SIDE, b)
        cv.jitter(*PK_SIDE, 0.1, 42)
        cv.vgrad(*PK_LID, shade(b, 1.15), shade(b, 0.8))
        cv.jitter(*PK_LID, 0.06, 43)
        cv.frame(*PK_LID, shade(b, 0.5))
        gold = hx("#e0b040")
        cv.rect(11, 38, 15, 43, gold)
        cv.rect(12, 39, 14, 42, shade(gold, 0.45))
        cv.vgrad(*PK_POCKET, shade(a, 0.95), shade(a, 0.72))
        cv.jitter(*PK_POCKET, 0.06, 45)
        for x in range(29, 43, 2):
            cv.set(x, 36, shade(a, 1.6))
        cv.frame(*PK_POCKET, shade(a, 0.5))
        return finish(cv, [PK_MAIN, PK_LID, PK_POCKET])

    return go


PACK_BOXES = [
    B(0, 6.0, 3.7, 6, 8, 3, PK_MAIN, PK_SIDE),
    B(0, 3.3, 3.95, 6.3, 2.8, 3.4, PK_LID, PK_SIDE),
    B(0, 8.8, 5.45, 4, 3, 0.6, PK_POCKET, PK_SIDE),
]
item("pack", "mochila", "Mochila", "comun", [dict(b) for b in PACK_BOXES], paint_pack("#8a5a2b", "#6b4120"), desc="Mochila de cuero con hebilla y bolsillo.", price=0)
item("pack", "rosa", "Mochila rosa", "raro", [dict(b) for b in PACK_BOXES], paint_pack("#e86aa6", "#b84e82", dots=True), desc="Mochila rosa con lunares de brillo.")

# --- Jetpack
JT_TANK, JT_EDGE, JT_CAP, JT_NOZ, JT_FLAME, JT_PIPE = (0, 0, 12, 36), (14, 0, 18, 4), (20, 0, 32, 8), (20, 10, 32, 18), (34, 0, 42, 12), (34, 14, 44, 18)


def paint_jet(cv):
    steel, red = hx("#8b8fa3"), hx("#c23b3b")
    for x in range(12):
        k = 0.78 + 0.5 * math.cos((x - 5.5) / 5.5 * 1.4)
        for y in range(36):
            cv.set(x, y, shade(steel, k))
    for x in range(12):  # banda roja y franjas de aviso
        for y in range(3, 7):
            cv.set(x, y, shade(red, 0.75 + 0.5 * math.cos((x - 5.5) / 5.5 * 1.4) * 0.5))
        for y in range(28, 32):
            cv.set(x, y, hx("#f0c040") if (x + y) % 4 < 2 else hx("#1a1a22"))
    for y in range(36):
        cv.set(0, y, shade(steel, 0.5))
        cv.set(11, y, shade(steel, 0.5))
    for y in (12, 20):
        for x in range(12):
            cv.set(x, y, shade(steel, 0.6))
    for x, y in ((3, 15), (8, 15), (3, 23), (8, 23)):
        cv.set(x, y, shade(steel, 1.5))
    cv.jitter(*JT_TANK, 0.04, 51)
    cv.rect(*JT_EDGE, hx("#4a4d5c"))
    cv.vgrad(*JT_CAP, hx("#d94a4a"), hx("#8a2020"))
    cv.frame(*JT_CAP, hx("#5a1414"))
    cv.vgrad(*JT_NOZ, hx("#5a5d70"), hx("#2a2c38"))
    for x in range(20, 32, 3):
        cv.line(x, 10, x, 17, hx("#15151d"))
    for y in range(12):
        t = y / 11
        c = mix(WHITE, hx("#19e3ff"), min(1, t * 1.6))
        for x in range(34, 42):
            w = 3.6 * (1 - t * 0.8)
            if abs(x - 37.5) <= w:
                cv.set(x, y, c, int(255 * (1 - t * 0.55)))
    cv.vgrad(*JT_PIPE, hx("#6a6d80"), hx("#3a3c4a"))
    return finish(cv, [JT_TANK, JT_CAP, JT_NOZ])


jet_boxes = []
for s in (1, -1):
    jet_boxes += [
        B(s * 2.4, 6.2, 4.4, 3.4, 9, 3.4, JT_TANK, JT_EDGE),
        B(s * 2.4, 1.2, 4.4, 3.6, 1.2, 3.6, JT_CAP, JT_CAP),
        B(s * 2.4, 11.4, 4.4, 2.6, 1.4, 2.6, JT_NOZ, JT_NOZ),
        B(s * 2.4, 13.6, 4.4, 1.8, 2.6, 1.8, JT_FLAME, JT_FLAME, glow=True, flags=1),
    ]
jet_boxes.append(B(0, 3.4, 4.4, 2.6, 1.2, 1.2, JT_PIPE, JT_PIPE))
item("pack", "jetpack", "Jetpack", "epico", jet_boxes, paint_jet, desc="Dos tanques con llama que se enciende al saltar.")


# ================================================================ SALIDA
def fl(v):
    return ("%.3f" % v).rstrip("0").rstrip(".") + "f" if "." in ("%.3f" % v) else "%.1ff" % v


def jstr(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def emit_java():
    out = []
    out.append("package com.ametra;")
    out.append("")
    out.append("import java.util.ArrayList;")
    out.append("import java.util.List;")
    out.append("")
    out.append("/** GENERADO por tools/gen_cosmetics.py — no editar a mano. Geometría y UV de los cosméticos. */")
    out.append("public final class CosmeticData {")
    out.append("    private CosmeticData() {}")
    out.append("")
    out.append("    /** Caja en píxeles de modelo. uv = cara frontal/trasera, uv2 = resto de caras (en texels de una hoja de 64x64). */")
    out.append("    public static final class B {")
    out.append("        public final float x, y, z, w, h, d, ry;")
    out.append("        public final float u0, v0, u1, v1, s0, t0, s1, t1;")
    out.append("        public final boolean glow;")
    out.append("        public final int flags;")
    out.append("")
    out.append("        B(float x, float y, float z, float w, float h, float d, float ry,")
    out.append("          int u0, int v0, int u1, int v1, int s0, int t0, int s1, int t1, boolean glow, int flags) {")
    out.append("            this.x = x; this.y = y; this.z = z; this.w = w; this.h = h; this.d = d; this.ry = ry;")
    out.append("            this.u0 = u0 / 64f; this.v0 = v0 / 64f; this.u1 = u1 / 64f; this.v1 = v1 / 64f;")
    out.append("            this.s0 = s0 / 64f; this.t0 = t0 / 64f; this.s1 = s1 / 64f; this.t1 = t1 / 64f;")
    out.append("            this.glow = glow; this.flags = flags;")
    out.append("        }")
    out.append("    }")
    out.append("")
    out.append("    public static final class Item {")
    out.append("        public final String cat, id, name, rar, tex;")
    out.append("        public final int price;")
    out.append("        public final B[] boxes;")
    out.append("")
    out.append("        Item(String cat, String id, String name, String rar, int price, B[] boxes) {")
    out.append("            this.cat = cat; this.id = id; this.name = name; this.rar = rar; this.price = price; this.boxes = boxes;")
    out.append('            this.tex = cat + "_" + id;')
    out.append("        }")
    out.append("    }")
    out.append("")
    out.append("    public static final List<Item> ALL = new ArrayList<>();")
    out.append("")
    out.append("    public static Item find(String cat, String id) {")
    out.append("        if (id == null) return null;")
    out.append("        for (Item it : ALL) if (it.cat.equals(cat) && it.id.equals(id)) return it;")
    out.append("        return null;")
    out.append("    }")
    out.append("")
    out.append("    static {")
    for it in ITEMS:
        out.append("        ALL.add(new Item(%s, %s, %s, %s, %d, new B[] {" % (jstr(it["cat"]), jstr(it["id"]), jstr(it["name"]), jstr(it["rar"]), it["price"]))
        for b in it["boxes"]:
            u, s = b["uv"], b["uv2"]
            out.append("            new B(%s, %s, %s, %s, %s, %s, %s, %d, %d, %d, %d, %d, %d, %d, %d, %s, %d),"
                       % (fl(b["x"]), fl(b["y"]), fl(b["z"]), fl(b["w"]), fl(b["h"]), fl(b["d"]), fl(b["ry"]),
                          u[0], u[1], u[2], u[3], s[0], s[1], s[2], s[3], "true" if b["glow"] else "false", b["flags"]))
        out.append("        }));")
    out.append("    }")
    out.append("}")
    with open(JAVA_OUT, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")


LAUNCHER_DIR = os.path.join(ROOT, "assets", "cosmetics")


def emit_launcher():
    """Copia los PNG al launcher y genera assets/cosmetics/data.js (geometría + UV + precios)."""
    import json
    import shutil
    os.makedirs(LAUNCHER_DIR, exist_ok=True)
    out = []
    for it in ITEMS:
        name = "%s_%s.png" % (it["cat"], it["id"])
        shutil.copyfile(os.path.join(TEX_DIR, name), os.path.join(LAUNCHER_DIR, name))
        out.append(dict(cat=it["cat"], id=it["id"], name=it["name"], rar=it["rar"], price=it["price"], desc=it["desc"], tex=name,
                        boxes=[dict(x=b["x"], y=b["y"], z=b["z"], w=b["w"], h=b["h"], d=b["d"], ry=b["ry"], uv=list(b["uv"]), uv2=list(b["uv2"]),
                                    glow=b["glow"], flags=b["flags"]) for b in it["boxes"]]))
    with open(os.path.join(LAUNCHER_DIR, "data.js"), "w", encoding="utf-8", newline="\n") as f:
        f.write("// GENERADO por tools/gen_cosmetics.py: no editar a mano.\nconst COS_DATA = " + json.dumps(out, ensure_ascii=False) + ";\n")


def main():
    for it in ITEMS:
        cv = Cv()
        it["paint"](cv)
        cv.save("%s_%s" % (it["cat"], it["id"]))
    emit_java()
    emit_launcher()
    print("OK: %d cosméticos -> %s" % (len(ITEMS), TEX_DIR))


if __name__ == "__main__":
    main()
